(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"120x600_atlas_", frames: [[122,0,120,259],[0,0,120,290],[0,292,120,115],[122,261,120,123]]}
];


// symbols:



(lib.goszakaz_120x600_2pngcopy2 = function() {
	this.spriteSheet = ss["120x600_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.goszakaz_120x600_4pngcopy = function() {
	this.spriteSheet = ss["120x600_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.goszakaz_120x600_7pngcopy3 = function() {
	this.spriteSheet = ss["120x600_atlas_"];
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.goszakaz_120x600_8 = function() {
	this.spriteSheet = ss["120x600_atlas_"];
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.goszakaz_120x600_4pngcopy();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol22, new cjs.Rectangle(0,0,120,290), null);


(lib.Symbol21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.goszakaz_120x600_2pngcopy2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol21, new cjs.Rectangle(0,0,120,259), null);


(lib.Symbol20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FB1136").s().p("AgQAoQAAgRAQAAQARAAAAARQAAARgRAAQgQAAAAgRgAgLAPIgFhHIAhAAIgFBHg");
	this.shape.setTransform(75.2,21.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FB1136").s().p("AAFAqIAAgeIgCAFQgCAHgEAHIgJALIgWAAIAAgMQAAgHAFgHIAHgIIgIgEQgEgEAAgLQAAgTAKgGQAHgFAPAAIAlAAIAABTgAgFgKQAAAGAFAAIAFAAIAAgMIgFAAQgFAAAAAGg");
	this.shape_1.setTransform(68.4,23.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FB1136").s().p("AgrA8IAAh2IAPAAIAMAHQAHgIANgBQAUAAAKALQAKAKAAAYQAAAWgKALQgJAJgWAAQgIAAgIgDIAAAkgAgMgZIgBAJIABAKQACAEAFAAIAFAAQAJAAADgEQABgCAAgHQAAgIgBgCQgDgEgJAAIgFAAQgFAAgCAEg");
	this.shape_2.setTransform(59.1,25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FB1136").s().p("AgkAvQgHgKAAgaQAAgrANgOQAHgHAWgCQATgBAJgDIAMAaQgNAIgaAAQgHAAgDADQgCACAAAFQAGgDAIAAQAWAAAKAIQAKAJAAAUQAAAVgLAKQgLAKgXAAQgaAAgJgNgAgJALQgDACAAAGQAAALAMAAQAOAAAAgLQAAgKgOAAQgGAAgDACg");
	this.shape_3.setTransform(48.9,21.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FB1136").s().p("AAFAqIAAgeIgCAFQgCAHgEAHIgIALIgXAAIAAgMQAAgHAFgHIAHgIIgIgEQgEgEAAgLQAAgTAKgGQAGgFAQAAIAlAAIAABTgAgEgKQgBAGAFAAIAGAAIAAgMIgGAAQgFAAABAGg");
	this.shape_4.setTransform(39.5,23.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FB1136").s().p("AgOAqIAAg4IgXAAIAAgbIBLAAIAAAbIgXAAIAAA4g");
	this.shape_5.setTransform(31.2,23.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FB1136").s().p("AAKAqIAAgeIgTAAIAAAeIgeAAIAAhTIAeAAIAAAbIATAAIAAgbIAeAAIAABTg");
	this.shape_6.setTransform(22.4,23.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FB1136").s().p("AgoAAQAAgrAoAAQApAAAAArQgLAGgTAAIgTAAQABAFADACIAHABQAPgBAMgDIAJAcQgRAGgTAAQgrAAAAgsgAgIgFIARAAQABgJgJAAQgKAAABAJg");
	this.shape_7.setTransform(12.9,23.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FB1136").s().p("AgaAhQgLgLAAgWQAAgWALgKQAKgLAXAAQATAAAMAIIgLAaQgKgEgJAAQgJAAgDADQgCADAAAHQAAAIACADQADADAJAAQAKAAAJgEIALAaQgOAIgRAAQgXAAgKgLg");
	this.shape_8.setTransform(3.8,23.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FB1136").s().p("AAAA5IAAgWIgvAAIAAgFQAAgLAIgTIAXg4IAlAAIgbA8IAHAAQACgKAHgIIAJgNIAPAAIAAAcIAOAAIAAAiIgOAAIAAAWg");
	this.shape_9.setTransform(71.2,5.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FB1136").s().p("AgIA5IAAhPIgRAAIAAgRIAZgRIAaAAIAABxg");
	this.shape_10.setTransform(62.7,5.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FB1136").s().p("AggAiQgLgLAAgXQAAgWALgLQALgKAVAAQAXAAAKAKQALALAAAWQAAAsgsAAQgVAAgLgKgAgIgKQgFACAAAIQAAAOANAAQAHAAADgDQADgDAAgIQAAgIgDgCQgDgCgHAAQgGAAgCACg");
	this.shape_11.setTransform(50.2,7.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FB1136").s().p("AAJAqIAAg5IgQAAIAAA5IgeAAIAAhTIBLAAIAABTg");
	this.shape_12.setTransform(40.5,7.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FB1136").s().p("AghAtQgKgNAAgfQAAggAKgMQAJgOAYgBQAYABAKAOQAKAMAAAgQAAAfgKANQgKAOgYgBQgYABgJgOgAgGgSQgCAGAAANQAAAOACAEQABAHAFgBQAFABACgHQABgEAAgOIgBgTQgCgGgFAAQgFAAgBAGg");
	this.shape_13.setTransform(26,5.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FB1136").s().p("AgIA5IAAhPIgRAAIAAgRIAZgRIAaAAIAABxg");
	this.shape_14.setTransform(17.3,5.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FB1136").s().p("AgaAhQgLgKAAgXQAAgWALgKQAKgLAXAAQASAAANAIIgLAaQgJgEgKAAQgJAAgDADQgCADAAAHQAAAIACADQADADAJAAQAIAAALgEIALAaQgOAIgRAAQgXAAgKgLg");
	this.shape_15.setTransform(5.4,7.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol20, new cjs.Rectangle(0,0,77,31), null);


(lib.Symbol19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1E1A16").s().p("AgPAvQgCgCgBgFIABgFIAEgEIADgDIAGgBQAEAAABADQADACAAAEIgBAFIgDAEIgDADIgGABQgEAAgCgCgAgKATIALhDIARAAIgOBDg");
	this.shape.setTransform(67.2,21);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1E1A16").s().p("AAOAjIAGgiIAAAAIgSAZIgMAAIgJgZIAAAAIAAAAIgHAiIgSAAIAOhFIAQAAIANAnIABAAIAcgnIAQAAIgNBFg");
	this.shape_1.setTransform(60.7,22.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E1A16").s().p("AgOAiQgFgCgEgDQgDgDgDgEQgCgFAAgGIAAgEIADgQQADgMAIgIQAIgFAMgBIAMACQAGACADADQAEADACAFQACAGAAAEIgBAHIgDAOQgCALgJAIQgIAFgNAAgAgFgPQgEADgBAGIgDALIAAAEQAAABAAABQAAAAAAABQABAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQAAABABAAQAAAAABAAIADACIAEABQAEAAAEgDQAEgDABgGIADgPQAAgEgEgDQgCgDgGAAQgEAAgDADg");
	this.shape_2.setTransform(52.6,22.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E1A16").s().p("AAGAjIAFgcIgYAAIgGAcIgRAAIAOhFIARAAIgFAbIAYAAIAFgbIASAAIgNBFg");
	this.shape_3.setTransform(45.3,22.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1E1A16").s().p("AAaAjIgDgTQAAgGgDgCQgDgBgFAAIgEAAIgFAcIgRAAIAGgcIgIAAIgEABIgDADIgDAFIgIATIgTAAIAKgXIAGgJQADgDAGgBQgEgBgDgEIgCgIIgDgUIASAAIADAQQABAGACACQADACAEAAIADAAIAFgaIARAAIgFAaIAEAAQAEAAACgCQAEgCACgGIAIgQIATAAIgJAUQgDAGgDADIgHAFQAFAAABAEQACADAAAFIAEAXg");
	this.shape_4.setTransform(36.4,22.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1E1A16").s().p("AgOAiQgFgCgDgDQgEgDgDgEQgCgGAAgFIADgUQADgMAIgIQAJgFAMgBIALACQAGACADADQAEADACAFQACAGAAAEIAAAHIgDAOQgDALgJAIQgHAFgNAAgAgFgPQgDADgCAGIgDAPQAAABAAAAQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAQAAABAAAAQABABAAAAQABAAAAAAIAEACIADABQAEAAAEgDQADgDACgGIADgPQAAgEgDgDQgDgDgFAAQgFAAgDADg");
	this.shape_5.setTransform(27.8,22.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1E1A16").s().p("AglAVIAHgDIAFgEQACgCABgFIAJgqIAzAAIgNBFIgSAAIALg1IgSAAIgBAPIgFAPQgCAIgEAFQgEAEgFADQgFAEgIABg");
	this.shape_6.setTransform(20.2,22.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1E1A16").s().p("AgOAiIgIgEQgEgFgBgCQgCgEAAgGIAAgCIAEgVQACgMAJgHQAIgFALgBIAHABIAHACIAGADIAFAFIgLAMQgEgDgEgCIgGgCQgFAAgDAEQgEADgBAGIgDANIAAABIAAABQAAAGADACQADACAEAAIAGgCQADAAAGgEIAKANQgHAGgHABQgGACgIAAQgFAAgFgBg");
	this.shape_7.setTransform(13.9,22.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1E1A16").s().p("AgOAiQgFgCgEgDQgDgDgCgEQgDgGAAgFIABgEIAAgDIADgNQACgMAIgIQAIgFAMgBQAHAAAFACQAGACADADQAEAEABAEQADAFAAAFIgEAVQgCAMgIAHQgJAFgNAAgAgFgPQgEADgBAGIgDAPIABAFIADACIADACIAFABQADAAAEgDQADgDACgGIADgPQAAgEgEgDQgCgDgGAAQgEAAgDADg");
	this.shape_8.setTransform(3.2,22.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1E1A16").s().p("AgOAiQgEgBgEgDQgEgEgCgEQgDgFAAgGIAAgDIAEgRQACgNAIgGQAJgHAMAAQAEABAHACQAFABAEADQAFAFABADQACAEAAAGIgDAVQgDANgIAGQgIAFgOAAQgFAAgFgBgAgFgPQgDACgCAIIgDAOIABAFIADADQABAAAAABQAAAAABAAQAAAAABAAQAAAAABAAIAEACQAEgBADgDQAEgCABgHIADgOQAAgFgDgDQgEgDgEAAQgEAAgEADg");
	this.shape_9.setTransform(54.7,6.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1E1A16").s().p("AAaAjIAJgqIAAgBIAAgCQAAgCgCgDQgBgCgEAAIgGABIgJAFIgJAuIgRAAIAJgpIAAgEQAAgDgCgCQgBgCgEAAIgGACIgJAFIgJAtIgSAAIANhEIARAAIAAADIAAADIAHgEIAGgCIAHgBQAFAAAEACQADACADAFIAIgFIAHgDIAJgBQAJAAAFAFQAEAFAAAIIgKAzg");
	this.shape_10.setTransform(45.3,6.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1E1A16").s().p("AgOAiQgEgBgEgDIgFgHQgCgGAAgEIAEgWQACgNAJgGQAIgHALAAIAHABIAHACQADAAADADIAFAFIgKANQgFgFgDgBIgHgBQgFAAgDADQgDACgCAHIgDANIAAADQAAAFADACQAEADADAAIAGgCQAFgBADgEIALANQgHAGgHACQgGABgIAAg");
	this.shape_11.setTransform(37,6.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1E1A16").s().p("AgOAiQgFgBgEgDQgDgEgDgEQgCgFAAgGIAAgDIAAgDIAEgOQACgNAIgGQAJgHALAAQAFABAHACQAFABAEADQAEAFABADQADAFAAAFIgDAVQgEANgHAGQgJAFgNAAIgKgBgAgFgPQgEACgBAIIgDAOIABAFIADADQAAAAABABQAAAAABAAQAAAAABAAQAAAAAAAAIAEACQAFgBADgDQADgCACgHIADgOQAAgGgDgCQgEgDgEAAQgEAAgEADg");
	this.shape_12.setTransform(29.9,6.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1E1A16").s().p("AglAxIAThgIAQAAIABAGIALgFIAJgCQAJAAAFAEQAFAFAAAIIgBAIIgEAVQgCAJgHAIQgIAHgMAAIgIgBIgJgDIgGAfgAAEgdIgJADIgFAbIAIADIAFABQAEAAAEgDQADgCACgFIADgUQAAgDgCgCQgCgCgDAAQgEAAgEADg");
	this.shape_13.setTransform(22.1,7.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#1E1A16").s().p("AAJAxIAPhPIgjAAIgPBPIgTAAIAShhIBJAAIgSBhg");
	this.shape_14.setTransform(14.8,4.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol19, new cjs.Rectangle(0,0,69.1,26), null);


(lib.Symbol18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FB1136").s().p("AgMBLQgFgGAAgHQAAgHAFgGQAFgEAHAAQAIAAAFAEQAFAGAAAHQAAAHgFAGQgEAFgJABQgIgBgEgFgAgMAfIgBhvIAbAAIgBBvg");
	this.shape.setTransform(94.7,54);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FB1136").s().p("AgRBPIgPgDIgNgFQgIgDgDgEIAQgXIAIAFIAJAEIATADQAPAAAHgGQAIgGAAgKQAAgKgIgGQgIgFgKAAIgUAAIAAgYIAUAAQADAAAFgBQAGgCACgCQAEgDABgEQACgDABgFQgBgGgCgDQgCgEgDgBQgGgDgDgBIgIgBQgIAAgKADQgJADgHAGIgPgWQAKgJANgDQAOgEAOAAQAMAAAIACQAKACAIAFQAHAGAFAIQAEAIAAAMQABALgHAJQgFAJgKAFQALADAGAKQAGAJAAALQAAANgFAKQgGAJgHAGQgIAGgLADQgJACgMAAIgQgBg");
	this.shape_1.setTransform(85,54);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FB1136").s().p("AgPBQIAAgNQgNgBgMgFQgLgEgJgIQgIgIgEgKQgFgKAAgNIAAgVQAAgLAFgMQAGgLAIgHQAIgHALgFQAOgEAKAAIAAgJIAfAAIAAAJQALAAANAEQAMAFAIAHQAJAIAEAKQAFALAAAMIAAAVQAAANgFAKQgEALgIAIQgIAHgMAFQgLAEgOABIAAANgAAQAmQANAAAJgIQAJgJAAgPIAAgQQAAgOgIgJQgJgIgOgBgAgbgoQgEACgGAFQgEAFgCAFQgDAFAAAIIAAAQQAAAJADAEQACAFAEAGQAFAEAFACQAHACAFAAIAAhQQgFAAgHACg");
	this.shape_2.setTransform(69.9,53.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FB1136").s().p("AglANIAAgZIBKAAIAAAZg");
	this.shape_3.setTransform(56,55.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FB1136").s().p("AAMBPIAAgXIhBAAIAAgXIAzhvIAdAAIgvBsIAgAAIAAgsIAeAAIAAAsIAMAAIAAAaIgMAAIAAAXg");
	this.shape_4.setTransform(45.1,54);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FB1136").s().p("AAMBPIAAgXIhBAAIAAgXIAyhvIAeAAIgwBsIAhAAIAAgsIAdAAIAAAsIANAAIAAAaIgNAAIAAAXg");
	this.shape_5.setTransform(32.9,54);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FB1136").s().p("AgPAvQgIgCgGgEQgFgEgEgHQgEgGABgKIAAgbQgBgJAEgGQADgGAGgGQAHgEAIgCQAGgDAIAAQAKAAAGADQAHACAHAEQAGAFADAHQAEAHgBAIIAAAbQABAKgEAGQgEAHgFAEQgGAEgJACQgGACgJAAQgIAAgHgCgAgFgYIgGACIgEAGQgBACAAAGIAAASQAAAFABADIAEAFIAGADIAFABIAGgBIAGgDIAEgFQABgDAAgFIAAgSQAAgGgBgCQgBgEgDgCQgCgCgEAAIgGgBIgFABg");
	this.shape_6.setTransform(16.6,57);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FB1136").s().p("AARAwIAAhKIghAAIAABKIgZAAIAAhgIBTAAIAABgg");
	this.shape_7.setTransform(6.3,57);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FB1136").s().p("AAnBDIAAhHIgBAAIgcA1IgSAAIgcg1IgBAAIAABHIgbAAIAAiGIAZAAIAnBQIABAAIAohQIAYAAIAACGg");
	this.shape_8.setTransform(91.3,29.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FB1136").s().p("AAgBDIgIgbIguAAIgJAbIgdAAIAwiGIAaAAIAvCGgAgPARIAfAAIgQgzIAAAAg");
	this.shape_9.setTransform(77.4,29.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FB1136").s().p("AAXBDIgLgmQgCgHgCgCQgCgEgDgCQgDgDgCAAIgXAAIAAA4IgaAAIAAiGIAaAAIAAA3IAOAAIAHgBIAGgCIAFgGIAEgJIAMglIAbAAIgMAoQgDALgFAFQgFAHgGACQAJADAEAGQAEAIADAJIANArg");
	this.shape_10.setTransform(65.4,29.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FB1136").s().p("AAYBDIAAhtIgwAAIAABtIgbAAIAAiGIBnAAIAACGg");
	this.shape_11.setTransform(52.7,29.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FB1136").s().p("AglBEIAAgVIAMAAQAGAAACgCQADgBACgEIABgCIABgCIgrhnIAcAAIAZBIIABAAIAZhEIABgEIAbAAIgnBlQgGASgJAJQgJAHgOAAg");
	this.shape_12.setTransform(40.8,29.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FB1136").s().p("AAXBDIgLgmQgCgIgCgBQgCgEgDgCQgDgDgCAAIgXAAIAAA4IgaAAIAAiGIAaAAIAAA3IAOAAIAHgBIAGgCIAFgGIAEgJIAMglIAbAAIgMAoQgDALgFAFQgFAHgGACQAJADAEAGQAEAIADAJIANArg");
	this.shape_13.setTransform(29.5,29.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FB1136").s().p("AAgBDIgJgbIguAAIgIAbIgdAAIAviGIAbAAIAvCGgAgPARIAgAAIgQgzIgBAAg");
	this.shape_14.setTransform(16.8,29.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FB1136").s().p("AgbBBQgHgBgFgDQgFgCgEgEIAOgUIAHAEIAIADIAJACIAHABQAMAAAGgFQAHgFAAgJQAAgJgGgEQgGgFgKAAIgRAAIAAgUIARAAIAHgBIAHgDQADgCABgEQACgDAAgEQAAgFgCgDIgFgEIgHgDIgHgBQgIAAgHADQgHACgHAFIgNgTQAJgHALgDQALgEANAAQAKAAAHACQAHABAIAFQAGAFAEAHQAEAIAAAJQAAALgFAHQgFAIgIADQAJADAGAIQAFAJAAAJQAAALgFAIQgDAHgIAGQgGAFgKACQgKADgIAAg");
	this.shape_15.setTransform(4.9,29.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#383236").s().p("AgtBEIAAiGIBbAAIAAAXIhAAAIAAAgIA3AAIAAAXIg3AAIAAAgIBAAAIAAAYg");
	this.shape_16.setTransform(91.8,6.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#383236").s().p("AAcBEIAAhXIgBAAIg4BXIgYAAIAAiGIAbAAIAABYIABAAIA3hYIAZAAIAACGg");
	this.shape_17.setTransform(79.4,6.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#383236").s().p("AAYBEIAAg5IgwAAIAAA5IgbAAIAAiGIAbAAIAAA2IAwAAIAAg2IAcAAIAACGg");
	this.shape_18.setTransform(66.5,6.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#383236").s().p("AguBEIAAiGIBcAAIAAAXIhBAAIAAAgIA4AAIAAAXIg4AAIAAAgIBBAAIAAAYg");
	this.shape_19.setTransform(54.7,6.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#383236").s().p("AAZBEIAAg4QgIAEgGABQgIACgIAAQgJAAgJgCQgIgDgHgGQgGgEgEgIQgDgKAAgKIAAgqIAbAAIAAAnQAAANAGAFQAGAGAMAAQAHAAAGgCIANgFIAAg4IAaAAIAACGg");
	this.shape_20.setTransform(42.6,6.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#383236").s().p("AglBEIAAgVIAMAAQAGAAACgCQADgBACgEIABgCIAAgCIgqhnIAcAAIAZBJIABAAIALgfIACgEIANgmIAbAAIgnBlQgHATgIAIQgJAHgNAAg");
	this.shape_21.setTransform(31.3,7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#383236").s().p("AgxBEIAAiGIBXAAIAAAXIg8AAIAAAcIAeAAQAKAAAIADQAHADAGAGQAGAFADAHQACAIAAAIQAAAJgCAHQgCAHgFAGQgEAEgJAGQgIAEgLAAgAgWAsIAaAAQAKAAAFgGQAFgEAAgJQAAgIgFgEQgFgFgKAAIgaAAg");
	this.shape_22.setTransform(20.2,6.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#383236").s().p("AgTBCQgKgDgHgFQgGgFgFgJQgEgJAAgKIAAgxQAAgLAFgIQADgHAIgHQAGgFALgDQAJgDAJAAQAKAAAJADQAJADAIAGQAIAGAEAHQAEAKAAAJIAAAxQAAAKgEAJQgFAJgGAFQgHAFgKADQgJADgLAAQgJAAgKgDgAgIgqQgEABgEAEQgEADgCAEQgCAFAAAGIAAAnQAAAHACAEQACAEAEAEQADACAFACQAEACAEgBQAFABAEgCQAFgCADgCQADgCADgGQACgEAAgHIAAgnQAAgGgCgFQgDgFgDgCQgEgEgEgBIgJgBQgEAAgEABg");
	this.shape_23.setTransform(7.8,6.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol18, new cjs.Rectangle(0,0,97.9,62), null);


(lib.Symbol17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FB1136").s().p("AgbB2IAAhAIA3AAIAABAgAgLAlIgOhOIgCgPIAAg9IA3AAIAAA9QAAAIgCAHIgMBOg");
	this.shape.setTransform(101.9,12.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FB1136").s().p("AhWB2IAAhAIBxAAIAAgfIhcAAIAAgxIBcAAIAAgeIhxAAIAAg9IB/AAQAuAAAAApIAAAnQAAAdgTAIQATAKAAAcIAAAnQAAApguAAg");
	this.shape_1.setTransform(87.6,12.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FB1136").s().p("AgcB3IAAgcIguAAQgnAAgMgPQgJgMAAggIAAhFQAAggAJgMQANgPAmgBIAuAAIAAgVIA5AAIAAAVIAuAAQAmABANAPQAJAKAAAiIAABFQAAAigJAKQgMAPgnAAIguAAIAAAcgAAdAeIAuAAIAAhBIguAAgAhKAeIAuAAIAAhBIguAAg");
	this.shape_2.setTransform(63.8,12);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FB1136").s().p("AgiAZIAAgxIBFAAIAAAxg");
	this.shape_3.setTransform(44.9,14.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FB1136").s().p("AAKB2IAAhAIhqAAIAAg5IBchyIBTAAIh8B8IA3AAIAAghIA9geIAAA/IAaAAIAAAvIgaAAIAABAg");
	this.shape_4.setTransform(30.3,12.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FB1136").s().p("AALB2IAAhAIhrAAIAAg5IBchyIBUAAIh9B8IA4AAIAAghIA9geIAAA/IAZAAIAAAvIgZAAIAABAg");
	this.shape_5.setTransform(9.7,12.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(210,32,54,0.149)").s().p("AAJAgIAeBpIAAAJgAAJAgIgJgjIgmiOIAmCOIAJAjg");
	this.shape_6.setTransform(109.4,33.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(210,32,54,0.149)").s().p("Ag6jAIA3AAIA/DjIAACeg");
	this.shape_7.setTransform(107.4,45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(210,32,54,0.149)").s().p("AhPkFIABACIACAEIABACIAAACIAFALIABAEIACABIAYA/IB7GcIAAAWg");
	this.shape_8.setTransform(105.4,35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(210,32,54,0.149)").s().p("Ag9jNIAbAAIBgFUIAABIg");
	this.shape_9.setTransform(107.2,38.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(210,32,54,0.149)").s().p("AglhcIgEg/IAAgBIgBgBIAAgQIAAgCIAAgBIgBgCIAAgDIgBgCIAAgBIgBgCIgNg9IB2GxIAAA+g");
	this.shape_10.setTransform(107.4,27);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(210,32,54,0.149)").s().p("AiglVICLgBIAJgCIAHgEIAFgEIAEgFIABgIIAAgJIgJgwIClIEIAAFJg");
	this.shape_11.setTransform(97.3,60);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(210,32,54,0.149)").s().p("AhgkAIAEgCIADgDIACgFIADgJIAAgMIgLguIDAJiIAAA4g");
	this.shape_12.setTransform(103.6,39.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(210,32,54,0.149)").s().p("AigmSIBcAAIDlKNIAACYg");
	this.shape_13.setTransform(97.2,56.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("rgba(251,17,54,0.149)").ss(0.3,0,0,22.9).p("AhBnLID4LMIAAC2IlquCg");
	this.shape_14.setTransform(95.1,54.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(210,32,54,0.149)").s().p("Ai0nAIBxAAID5LMIAAC1g");
	this.shape_15.setTransform(95.2,53.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(210,32,54,0.149)").s().p("Aj6njIA7AAIG6OOIAAA5g");
	this.shape_16.setTransform(88.3,74.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(210,32,54,0.149)").s().p("AkyofIADAEIAHAHIALAFIANAEIAIABIA/ABIH8PbIAABOg");
	this.shape_17.setTransform(82.7,75.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(210,32,54,0.149)").s().p("AjgmFIBHgDIALgDIAIgGIADgDIACgDIABgJIgBgRIgahrIF8OaIAACfg");
	this.shape_18.setTransform(90.9,62);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(210,32,54,0.149)").s().p("AjfnGIgQhDIHfQDIAAAQg");
	this.shape_19.setTransform(89.4,62.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(210,32,54,0.149)").s().p("AjvoBIAuAAIGxPRIAAAyg");
	this.shape_20.setTransform(89.4,61.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(210,32,54,0.149)").s().p("AkTn3IgQhDIJHRlIAAAQg");
	this.shape_21.setTransform(84.1,67.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(210,32,54,0.149)").s().p("AkjoyIAuAAIIZQ8IAAApg");
	this.shape_22.setTransform(84.1,66.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(210,32,54,0.149)").s().p("AjZm4IgHgcIHBOiIAAAIg");
	this.shape_23.setTransform(90.9,69.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(210,32,54,0.149)").s().p("Aj0oOIgFgWIHzRDIAAAFg");
	this.shape_24.setTransform(88.4,56.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(210,32,54,0.149)").s().p("Ak7oYIgMgxIKPSIIAAALg");
	this.shape_25.setTransform(80.6,72.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(210,32,54,0.149)").s().p("AlkpIIBFAAIKERiIAAAvg");
	this.shape_26.setTransform(77.7,77);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(210,32,54,0.149)").s().p("AlkoxIgMgwILhS4IAAALg");
	this.shape_27.setTransform(76.5,75.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(210,32,54,0.149)").s().p("Al3pRIAaAAILVSTIAAAQg");
	this.shape_28.setTransform(75.8,78.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(210,32,54,0.149)").s().p("Al1pDIgPhAIMJT5IAAAOg");
	this.shape_29.setTransform(74.5,72.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(210,32,54,0.149)").s().p("AmOpJIA9AAILgRyIAAAhg");
	this.shape_30.setTransform(73.5,84.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(210,32,54,0.149)").s().p("AnLp9IBrAAIMsTGIAAA1g");
	this.shape_31.setTransform(67.4,83.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(210,32,54,0.149)").s().p("AlooZIgPhAILvSjIAAAQg");
	this.shape_32.setTransform(75.8,79.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(210,32,54,0.149)").s().p("Am3pFIBgh9IMPUkIAABhg");
	this.shape_33.setTransform(69.3,72.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(210,32,54,0.149)").s().p("AnLpnIgLgwIOtUlIAAAKg");
	this.shape_34.setTransform(66.2,81);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(210,32,54,0.149)").s().p("AneqFIAaAAIOjUAIAAALg");
	this.shape_35.setTransform(65.5,83.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(210,32,54,0.149)").s().p("Ancp3IgPhAIPXViIAAANg");
	this.shape_36.setTransform(64.2,77.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(210,32,54,0.149)").s().p("An0p4IA8AAIOuTZIAAAYg");
	this.shape_37.setTransform(63.2,89.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(210,32,54,0.149)").s().p("AoyqlIBsAAIP5UjIAAAog");
	this.shape_38.setTransform(57.1,87.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(210,32,54,0.149)").s().p("AnOpMIgQhAIO9ULIAAAOg");
	this.shape_39.setTransform(65.5,84.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(210,32,54,0.149)").s().p("AoepwIBgh9IPdWOIAABOg");
	this.shape_40.setTransform(59.1,77.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol17, new cjs.Rectangle(0,0,114.4,155), null);


(lib.Symbol16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#383236").s().p("AgHAuQgDgCAAgGQAAgDADgEQADgEAEAAQAFAAADAEQADADAAAEQAAAGgCACQgEAEgFAAQgEAAgDgEgAgHATIgBhEIARAAIgBBEg");
	this.shape.setTransform(106.9,54);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#383236").s().p("AAUAjIAAgjIAAAAIgNAaIgMAAIgOgZIAAAiIgSAAIAAhFIARAAIAUAnIAAAAIAXgnIAPAAIAABFg");
	this.shape_1.setTransform(100.4,55.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#383236").s().p("AgLAjIgKgFIgGgJQgDgEAAgHIAAgTQAAgGADgGQADgFAEgDQAEgDAGgBIAKgCQAHAAAFACQAFABAFADQAEAEACAEQADAHAAAFIAAATQAAAGgDAFQgDAFgEAEIgKAFIgLABgAgDgSQgEABgBACIgDADIgBAGIAAAMIABAGIADAFIAEACIAEAAIAFAAIAEgCIADgFIABgGIAAgMIgBgGIgDgDIgEgDIgFAAg");
	this.shape_2.setTransform(92.2,55.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#383236").s().p("AghAVQADAAAEgCQADgCABgEQACgDABgDIAAgqIA1AAIAABFIgSAAIAAg2IgRAAIAAAPQAAASgGAKQgHALgPACg");
	this.shape_3.setTransform(84.5,55.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#383236").s().p("AgYAeQgGgFAAgLQAAgFADgFQACgEAEgBIAIgEIAJgBIARAAIAAgDQAAgFgDgCQgCgDgIAAIgIABQgEABgGAEIgIgNQAIgGAHgBQAFgCAIAAQAPAAAHAHQAHAGAAAOIAAArIgRAAIgBgFIAAgBQgHAEgFACIgIABQgKAAgHgGgAgEAHIgDABIgCACIgBADQAAABAAABQAAAAAAABQAAAAABABQAAAAABABQACACAEAAQAEAAAEgCQAFgCACgCIAAgIIgOAAg");
	this.shape_4.setTransform(77.3,55.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#383236").s().p("AANAjIAAgcIgZAAIAAAcIgSAAIAAhFIASAAIAAAbIAZAAIAAgbIASAAIAABFg");
	this.shape_5.setTransform(69.8,55.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#383236").s().p("AgKAjIgKgFIgHgJQgDgFAAgGIAAgTQAAgGADgGQADgEAEgEQADgDAHgBIAKgCIAMACQAHABADADQADADAEAFQACAFAAAHIAAATQAAAHgDAEIgGAJIgKAFIgMABgAgDgSIgFADIgCADQgCADAAADIAAAMIABAGIADAFIAEACIAEAAIAFAAIAEgCIADgFIABgGIAAgMIgBgGIgDgDIgEgDIgFAAg");
	this.shape_6.setTransform(62.3,55.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#383236").s().p("AANAjIAAgpIgBAAIgbApIgPAAIAAhFIASAAIAAAoIABAAIAagoIAQAAIAABFg");
	this.shape_7.setTransform(54.9,55.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#383236").s().p("AgJAjQgEgCgFgDQgEgFgCgEQgDgFAAgFIAAgUQAAgGADgGQADgEADgEQAEgDAGgBIAJgCIAHAAIAHACIAGACIAGAGIgKANQgEgFgEAAIgGgBIgEAAIgEADIgDADIgBAGIAAAMIABAGIADAFIAEACIAEAAIAGgBQAFgCADgDIALANIgHAEIgGAEIgOACg");
	this.shape_8.setTransform(48,55.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#383236").s().p("AgJAjIgJgFQgEgEgCgFQgDgFAAgFIAAgUQAAgGADgGQADgFAEgDQADgDAGgBQAFgCAEAAIAHAAIAHACIAGACIAHAGIgLANQgEgFgEAAIgGgBIgDAAQgDABgCACIgCADQgCADAAADIAAAMIABAGIADAFIAEACIAEAAIAHgBQAEgCADgDIALANIgHAEIgGAEIgOACg");
	this.shape_9.setTransform(41.6,55.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#383236").s().p("AgJAjIgKgFQgGgFgBgEQgDgFAAgGIAAgRQAAgGADgGQACgFAEgDQADgEAHgCIAKgCIAMACQAFABAEAFQAEADADAEQACAFAAAIIAAAMIgpAAIAAADIABAFIADAEIAEACIAEABIAIgBQAFgBAEgFIAJANIgGAFIgGADIgOACIgKgBgAgIgPQgDADAAAGIAAAAIAXAAIAAgBQAAgFgDgDQgEgDgFAAQgDAAgFADg");
	this.shape_10.setTransform(34.6,55.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#383236").s().p("AgIA/IAAgbQgGAAgHgDQgHgCgDgEQgEgEgDgFQgCgHAAgGIAAgKQAAgGACgGQADgGAEgDQAEgFAGgCIANgCIAAgbIARAAIAAAbIANACQAEACAGAFQAEADACAGQADAGAAAGIAAAKQAAAGgDAHQgCAFgEAEQgFAEgFACQgGADgHAAIAAAbgAAJATQAHAAADgFQAEgEAAgGIAAgIQAAgFgDgFQgEgEgHAAgAgSgOQgEAFAAAFIAAAIQAAAGAEAEQAEAFAGAAIAAglQgHAAgDAEg");
	this.shape_11.setTransform(26.3,55.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#383236").s().p("AgKAjIgKgFIgHgJQgDgFAAgGIAAgTQAAgGADgGQADgFAEgDQADgDAHgBIAKgCQAHAAAFACQAHABADADQADADAEAFQACAFAAAHIAAATQAAAHgDAEQgCAEgFAFIgJAFIgMABgAgDgSIgFADIgCADQgCADAAADIAAAMIABAGIADAFIAEACIAEAAIAFAAIAEgCIADgFIABgGIAAgMIgBgGIgDgDIgEgDIgFAAg");
	this.shape_12.setTransform(17.9,55.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#383236").s().p("AgeAxIAAhhIARAAIABAHIALgGIAIgCQALABAHAGQAGAHAAAMIAAAVQAAAKgGAHQgGAIgNgBIgIgBQgDAAgHgCIAAAegAgIgcIgEADIAAAbIAJACIAGABQADAAADgCQAEgCAAgGIAAgQQAAgGgDgDQgCgCgEAAIgEAAg");
	this.shape_13.setTransform(10.6,56.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#383236").s().p("AANAjIAAg1IgZAAIAAA1IgSAAIAAhFIA9AAIAABFg");
	this.shape_14.setTransform(3.1,55.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#383236").s().p("AgdAjIAAhFIASAAIAAAZIAPAAQAMAAAHAHQAGAFAAAJIAAAJQgCAEgEADQgBADgGADQgEABgIAAgAgMAUIAPAAQAEAAADgCQACgDAAgDIgCgEQgCgDgFAAIgPAAg");
	this.shape_15.setTransform(65.9,39);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#383236").s().p("AgIAjIAAg1IgUAAIAAgQIA5AAIAAAQIgUAAIAAA1g");
	this.shape_16.setTransform(59.2,39);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#383236").s().p("AAYAjIAAhFIASAAIAABFgAgpAjIAAhFIASAAIAAAZIAQAAQALAAAHAHQAGAFABAJIgCAJQgBAEgDADQgDADgFADQgEABgHAAgAgXAUIAPAAQAFAAACgCQABgCAAgEQAAgDgBgBQgCgDgFAAIgPAAg");
	this.shape_17.setTransform(51.3,39);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#383236").s().p("AgMAzQgGgCgDgDQgEgDgDgFQgCgGAAgGIABgeIABgLIAEgJIAFgHIAGgFIAMgHIAWgJIAGAPIgFACIgEABIgGADIgIAEIgHAEIgFAFQgCAEgBAEIAAAAIAEgCIAHgCIAEAAQAHAAADABQAHACADADQADADACAFQACAEAAAHIAAAPQAAAHgCAFQgDAEgEAEQgDACgHADIgMACIgMgCgAgDACQgBAAAAAAQgBAAAAABQgBAAAAAAQgBABgBAAIgDAEIgBAGIAAAKIABAGIADADIAEACIAEABIAFgBIAEgCIADgDIABgGIAAgLQAAgGgEgDQgEgDgFAAIgDABg");
	this.shape_18.setTransform(42.7,37.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FB1136").s().p("AgjAxIAAhhIATAAIAAAlIAVAAQAHAAAHADQAFACAEAEQAFADABAFQACAFABAIQgBAFgBAFIgGAKQgCAEgHADQgFADgJAAgAgQAgIATAAQAGAAAFgEQAEgFAAgEQAAgGgEgDQgFgEgGAAIgTAAg");
	this.shape_19.setTransform(100.6,21.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FB1136").s().p("AgIAxIAAhPIgbAAIAAgSIBHAAIAAASIgaAAIAABPg");
	this.shape_20.setTransform(92.3,21.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FB1136").s().p("AgIAwQgGgCgHgEQgFgEgDgFQgDgHgBgIIAAgkQABgHADgGQADgGAFgEQAFgDAHgDIAMgCQAJAAAIACQAIADAFAFIgJAPQgEgEgGgCIgKgBIgGABQgDABgCACIgFAGIgBAIIAAAbQAAAFABAEIAFAFIAGADIAFABIAKgBQAGgCAEgEIAJAPQgFAFgIACQgIADgIAAQgFAAgHgCg");
	this.shape_21.setTransform(84.8,21.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FB1136").s().p("AgOAwQgIgEgEgDQgEgDgEgGQgCgHAAgIIAAgjQAAgHACgGQADgGAGgEIAMgGQAGgCAHAAQAIAAAGACQAHACAFAFQAGADADAHQACAFAAAIIAAAiQAAAIgCAHQgEAGgEADQgEADgIAEQgKACgFAAQgFAAgJgCgAgGgeIgFADIgFAGIgBAIIAAAbQAAAFABAEIAFAFIAFADIAGABIAHgBIAFgDIAFgFQABgEAAgFIAAgbIgBgIIgFgGIgFgDIgHgBg");
	this.shape_22.setTransform(76.1,21.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FB1136").s().p("AASAxIAAgpIgjAAIAAApIgTAAIAAhhIATAAIAAAoIAjAAIAAgoIATAAIAABhg");
	this.shape_23.setTransform(67,21.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FB1136").s().p("AApAxIgIgcIgCgHIgEgEIgFgCIgMAAIAAApIgTAAIAAgpIgMAAIgEACIgFAEQgCADAAAEIgIAcIgVAAIAJgfQACgJADgEQAEgEAGgCQgDgBgFgFQgEgFgBgHIgJgdIATAAIALAhIAFAEIAEACIALABIAAgoIATAAIAAAoIALgBIAEgCIAFgEIACgGIAJgbIATAAIgIAdQgDAHgDAFQgDAFgFABQAGACAEAEQADAEACAJIAKAfg");
	this.shape_24.setTransform(55.9,21.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FB1136").s().p("AgOAwQgIgEgDgDQgGgEgCgFQgEgGABgJIAAgjQgBgHAEgGQAEgHAEgDIAMgGQAGgCAHAAQAIAAAGACQAHACAGAFQAEAEAEAGQACAFAAAIIAAAiQAAAKgCAFQgCAFgGAEQgCADgKAEIgPACIgOgCgAgGgeQgDABgCACQgDADgBADIgCAIIAAAbQAAAFACAEQABADADACQACACADABIAGABIAHgBQADgBACgCIAFgFQABgDAAgGIAAgbQAAgGgBgCIgFgGQgCgCgDgBIgHgBg");
	this.shape_25.setTransform(44.9,21.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FB1136").s().p("AAcAxIAAgzIgBAAIgUAmIgNAAIgUgmIgBAAIAAAzIgTAAIAAhhIASAAIAcA6IABAAIAdg6IARAAIAABhg");
	this.shape_26.setTransform(34.8,21.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FB1136").s().p("AgKAxIgJgCQgFgBgEgCIgGgEIAKgPIAFAEIAMAEIAFAAQAIgBAFgDQAFgEAAgGQAAgGgFgEQgEgDgHAAIgMAAIAAgPIAMAAIAFAAIAFgDIADgDQACgDAAgDIgCgGIgDgDQgDgBgDAAIgFgBIgKACQgGABgEAEIgKgOQAHgFAIgCQAIgDAJAAQAGAAAGABQAHACAEAEQAEADADAEQADAGAAAHQAAAGgDAHQgEAEgGAEQAGABAFAGQADAGAAAHQAAAIgDAGQgCAFgGAEQgEAEgIACQgFACgHAAg");
	this.shape_27.setTransform(25.1,21.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FB1136").s().p("AgNAwQgKgEgDgDQgDgCgFgHQgCgFgBgKIAAgjQAAgIADgFQAEgHAFgDQAEgDAIgDQAFgCAIAAQAHAAAHACQAGACAGAFQAEADAEAHQADAGAAAHIAAAiQAAAGgDAJQgDAFgFAEQgDADgJAEQgIACgGAAQgFAAgIgCgAgGgeQgDABgCACIgFAGIgCAIIAAAbQABAFABAEIAFAFQACACADABIAGABIAGgBQAEgBACgCQADgCABgDIACgJIAAgbIgCgIQgBgDgDgDQgCgCgEgBIgGgBg");
	this.shape_28.setTransform(16.9,21.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FB1136").s().p("AgkAxIAAhhIArAAQAIAAAFACQAFADAEADIAFAJIACAKQAAAGgEAFQgCAFgHAEIAGADQADACACAEIACAGIABAGIgCALQgCAGgDAEQgEAEgFACQgEACgIAAgAgRAgIAUAAQAHAAADgEQAEgDAAgGQAAgFgEgEQgEgDgGAAIgUAAgAgRgJIAUAAQAGAAADgDQADgDAAgEQAAgFgDgDQgDgDgHAAIgTAAg");
	this.shape_29.setTransform(8,21.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FB1136").s().p("AghAxIAAhhIBDAAIAAARIgvAAIAAAXIAoAAIAAAQIgoAAIAAAXIAvAAIAAASg");
	this.shape_30.setTransform(93.5,5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FB1136").s().p("AgJAxIAAhQIgaAAIAAgRIBGAAIAAARIgZAAIAABQg");
	this.shape_31.setTransform(85.6,5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FB1136").s().p("AAUAxIAAg/IgBAAIgoA/IgSAAIAAhhIAUAAIAAA/IAAAAIAog/IATAAIAABhg");
	this.shape_32.setTransform(77.1,5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FB1136").s().p("AgJAxIAAhQIgaAAIAAgRIBHAAIAAARIgaAAIAABQg");
	this.shape_33.setTransform(68.5,5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FB1136").s().p("AgJAwQgIgDgDgDQgGgEgDgGQgDgIAAgGIAAgjQAAgIADgGQAEgHAEgDQADgCAJgEIANgCQAIAAAIACQAJADAEAFIgJAPQgFgEgEgCIgLgBIgGABIgGADIgDAFIgCAIIAAAcQAAAFACADQABADADADQACACADABIAGABIALgCQAEgBAFgEIAJAPQgDAEgKADQgJADgHAAQgHAAgGgCg");
	this.shape_34.setTransform(61,5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FB1136").s().p("AgbAxIAAgPIAJAAIAGgCQADgBABgDIAAgBIABgBIgfhLIAUAAIASA0IABAAIAIgVIABgEIACgFIAHgTIABgDIATAAIgcBKQgFAMgGAHQgGAFgKAAg");
	this.shape_35.setTransform(52.8,5.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FB1136").s().p("AASAxIAAhQIgjAAIAABQIgTAAIAAhhIBJAAIAABhg");
	this.shape_36.setTransform(44.2,5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FB1136").s().p("AgbAxIAAgPIAJAAIAGgCQADgBABgDIAAgBIABgBIgfhLIAUAAIASA0IABAAIAJgZIAKgbIATAAIgcBKQgFAMgGAHQgGAFgKAAg");
	this.shape_37.setTransform(35.5,5.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FB1136").s().p("AghAxIAAhhIBDAAIAAARIgvAAIAAAXIAoAAIAAAQIgoAAIAAAXIAvAAIAAASg");
	this.shape_38.setTransform(23.9,5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FB1136").s().p("AASAxIAAgpIgjAAIAAApIgUAAIAAhhIAUAAIAAAnIAjAAIAAgnIATAAIAABhg");
	this.shape_39.setTransform(15.1,5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol16, new cjs.Rectangle(0,0,108,61.7), null);


(lib.Symbol15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FB1136").s().p("AgFAwQgEgEAAgEQAAgFAEgEQADgCADAAQAFAAAEACQADAFAAAEQAAACgDAGQgCACgGAAQgFAAgCgCgAgHAVIAAgEQAAgFADgFIAFgIIAFgKQADgEAAgGQAAgDgDgFQgEgCgEAAQgFAAgFABIgIAGIgJgPQAHgGAHgCQAJgCAGAAQAIAAAEACQAGACADAEQAFADACAFQACADAAAHIgCAIIgDAHIgNASQgCADAAAEIAAAEg");
	this.shape.setTransform(88.9,70.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FB1136").s().p("AAcAxIAAgzIAAAAIgUAmIgOAAIgUgmIgBAAIAAAzIgTAAIAAhhIASAAIAcA6IABAAIAcg6IASAAIAABhg");
	this.shape_1.setTransform(79.9,70.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FB1136").s().p("AAXAxIgGgUIgiAAIgGAUIgVAAIAjhhIATAAIAjBhgAgKANIAWAAIgMgmIAAAAg");
	this.shape_2.setTransform(69.8,70.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FB1136").s().p("AARAxIgLgjIgDgEIgFgCIgEAAIgMAAIAAApIgTAAIAAhhIATAAIAAAoIAQgBIAEgCQABgBACgDQACgBABgFIAIgbIAUAAIgJAdQAAAFgFAGQgEAGgEACQAHAAACAGQAEAFACAGIAJAgg");
	this.shape_3.setTransform(61.1,70.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FB1136").s().p("AASAxIAAhPIgjAAIAABPIgTAAIAAhhIBJAAIAABhg");
	this.shape_4.setTransform(51.9,70.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FB1136").s().p("AgbAyIAAgQIAJAAQAFAAABgBQACgBACgDIABgCIAAgBIgfhLIAUAAIASA1IABAAIAJgZIACgGIAFgNIACgGIABgDIATAAIgcBKQgFANgGAGQgHAGgJAAg");
	this.shape_5.setTransform(43.2,70.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FB1136").s().p("AARAxIgJgcIgCgHIgDgEIgFgCIgEAAIgMAAIAAApIgTAAIAAhhIATAAIAAAoIAQgBQABAAAAAAQABAAAAgBQAAAAAAAAQABgBAAAAQACgBACgDIADgGIAIgbIAUAAIgJAdQgBAGgEAFQgEAGgEACQAGAAADAGQAEAFACAGIAJAgg");
	this.shape_6.setTransform(35,70.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FB1136").s().p("AAYAxIgHgUIghAAIgGAUIgVAAIAihhIATAAIAiBhgAgKANIAWAAIgMgmIAAAAg");
	this.shape_7.setTransform(25.8,70.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FB1136").s().p("AgKAxIgSgFIgGgEIAJgPIAGAEIAFACIAMACQAJAAAEgEQAFgEAAgGQAAgHgFgDQgEgDgHAAIgNAAIAAgOIANAAIAFgBIAFgDIADgEQACgCAAgDQAAgDgCgCQAAgBgBAAQAAgBgBAAQAAgBgBAAQAAAAgBgBIgFgCIgFAAIgKABQgHACgDAEIgKgOQAHgFAHgCQAJgDAIAAQAHAAAGACQAGABAFADQAFAEACAEQADAGAAAHQAAAIgEAFQgEAFgFADQAHABADAGQAEAHAAAHQAAAIgDAFQgDAGgFAEQgGAEgGABIgMACg");
	this.shape_8.setTransform(17.2,70.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FB1136").s().p("AgWAIIAAgPIAtAAIAAAPg");
	this.shape_9.setTransform(76.2,55.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FB1136").s().p("AgJAwQgGgCgGgEQgFgEgDgFQgEgGAAgIIAAgkQAAgIAEgGQADgGAFgEQAFgEAHgBQAFgDAIAAQAKAAAGADQAHACAHAFIgKAPQgGgFgDAAIgLgCIgGABQgEACgBABIgEAGQgCADAAAFIAAAcQAAAEACAEQABAEADABQACACAEABIAFABQAHAAADgBIAKgFIAKAPQgEADgKAEQgGACgKAAQgHAAgGgCg");
	this.shape_10.setTransform(69.4,54);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FB1136").s().p("AgOAwQgHgCgFgEQgFgFgDgFQgDgGAAgIIAAgjQAAgIADgGQADgGAGgEQADgCAJgEIANgCQAIAAAGADQAFABAHAEQADADAFAIQAEAFAAAIIAAAjQAAAIgEAGQgBAEgHAGQgFAEgHACIgOACQgHAAgHgCgAgGgeQgDABgCACIgFAGIgBAIIAAAcIABAIQACADADACQACACADABIAGABIAHgBQADgBACgCQADgBABgEQACgEAAgEIAAgcQAAgFgCgDIgEgGQgCgCgDgBIgHgBg");
	this.shape_11.setTransform(60.7,54);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FB1136").s().p("AghAxIAAhhIBDAAIAAASIgwAAIAABPg");
	this.shape_12.setTransform(52.9,54.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FB1136").s().p("AgNAwQgHgCgGgEQgFgFgCgFQgEgGAAgIIAAgjQAAgIAEgGQAFgHADgDQADgCAJgEIANgCQAJAAAFADQAGABAGAEQAFAFADAGQADAGABAHIAAAjQgBAIgDAGQgBAEgHAGQgEAEgIACQgGACgIAAIgNgCgAgFgeQgFABgCACIgDAGIgDAIIAAAcIADAIIADAFQACACAFABIAFABQAFAAABgBQAEgBADgCQACgCACgDIABgIIAAgcIgBgIIgEgGQgDgCgEgBIgGgBg");
	this.shape_13.setTransform(40.4,54);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FB1136").s().p("AASAxIAAhPIgjAAIAABPIgUAAIAAhhIBLAAIAABhg");
	this.shape_14.setTransform(31.3,54.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#383236").s().p("AAcAxIAAg0IgBAAIgTAmIgOAAIgUgmIAAAAIAAA0IgUAAIAAhhIASAAIAcA5IABAAIAdg5IARAAIAABhg");
	this.shape_15.setTransform(101.2,37.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#383236").s().p("AgOAwQgJgEgCgCQgEgEgFgHQgDgHAAgHIAAgiQAAgHAEgHQADgHAFgDQAGgFAGgBIANgCQAIAAAGACQAJAEADACQAHAGABAFQAEAFAAAIIAAAiQAAAJgDAFQgDAHgFAEQgDACgJAEQgHACgIAAIgOgCgAgGgeQgEABgBACIgEAFQgCAEAAAFIAAAbQAAAEACAFQACAEACABQACACADABIAGABIAHgBQADAAACgDQADgCABgDQACgEAAgFIAAgbQAAgGgCgDQgBgDgDgCQgBgCgEgBQgCgBgFAAQgDAAgDABg");
	this.shape_16.setTransform(91.1,37.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#383236").s().p("AgIAxIAAhPIgbAAIAAgSIBHAAIAAASIgaAAIAABPg");
	this.shape_17.setTransform(83.2,37.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#383236").s().p("AgIAwQgHgCgGgEQgFgEgDgGQgDgFAAgJIAAgjQAAgJADgFQADgHAFgDQADgCAJgEIANgCQAIAAAIACQAJAEAEADIgJAQQgEgEgGgCIgKgBIgGABIgFADIgFAFQgBADAAAGIAAAbQAAAFABAEIAFAFQADACADABQABABAEAAIAKgBQAFgCAFgEIAJAPQgDAFgJACQgHADgKAAQgHAAgFgCg");
	this.shape_18.setTransform(75.7,37.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#383236").s().p("AAUAxIAAg/IAAAAIgkA4IgFAHIgSAAIAAhhIAUAAIAAA/IABAAIAog/IASAAIAABhg");
	this.shape_19.setTransform(66.7,37.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#383236").s().p("AgpAiQAFgBAFgEQACgCAEgGQACgGAAgFIABgPIAAgsIBAAAIAABhIgVAAIAAhPIgYAAIAAAZQAAANgCAIQgBALgEAHQgDAHgHAFQgFAEgMABg");
	this.shape_20.setTransform(56.9,37.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#383236").s().p("AAXAxIgGgVIghAAIgGAVIgVAAIAihhIATAAIAiBhgAgLAMIAXAAIgLglIgBAAg");
	this.shape_21.setTransform(48.2,37.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#383236").s().p("AATAxIAAg/IAAAAIgoA/IgRAAIAAhhIATAAIAAA/IAAAAIApg/IASAAIAABhg");
	this.shape_22.setTransform(38.9,37.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#383236").s().p("AAYA8IAAgWIhBAAIAAhhIATAAIAABPIAjAAIAAhPIAUAAIAABQIAJAAIAAAng");
	this.shape_23.setTransform(29.6,38.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#383236").s().p("AghAxIAAhhIBDAAIAAASIgwAAIAAAWIApAAIAAAQIgpAAIAAAXIAwAAIAAASg");
	this.shape_24.setTransform(20.6,37.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#383236").s().p("AASAxIAAhPIgjAAIAABPIgTAAIAAhhIBJAAIAABhg");
	this.shape_25.setTransform(11.7,37.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#383236").s().p("AgJAwIgMgGQgFgEgEgGQgCgGgBgIIAAgjQABgIACgGQAEgHAFgDQACgCAKgEQAGgCAGAAQAJAAAIACQAJAEAEADIgJAQQgEgEgGgCIgLgBIgFABIgFADIgFAFQgBADAAAGIAAAbQAAAFABAEIAFAFIAFADIAFABIALgBQAGgCAEgEIAJAPQgFAFgHACQgIADgKAAIgMgCg");
	this.shape_26.setTransform(3.4,37.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#383236").s().p("AghAxIAAhhIBDAAIAAASIgvAAIAAAWIAoAAIAAARIgoAAIAAAXIAvAAIAAARg");
	this.shape_27.setTransform(80.2,21.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#383236").s().p("AgJAxIAAhPIgaAAIAAgSIBHAAIAAASIgaAAIAABPg");
	this.shape_28.setTransform(72.3,21.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#383236").s().p("AgNAwQgIgCgEgEQgGgFgDgFQgCgFAAgJIAAgjQAAgJACgFQAFgHAEgDIAMgGIANgCIAOACQAHADAFAEQAFAEAEAFQACAHAAAIIAAAiQAAAHgCAHQgDAFgFAFQgGAEgHACQgFACgJAAQgIAAgFgCgAgGgeIgGADIgEAGQgBADAAAFIAAAbQAAAFABADQACAFACABIAGADIAGABIAGgBQAEAAACgDQADgCACgEIABgIIAAgbIgBgIIgFgGQgDgDgDAAIgGgBg");
	this.shape_29.setTransform(64,21.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#383236").s().p("AgkAxIAAhhIA/AAIAAASIgrAAIAAAUIAVAAQAJAAAEACQAGABAEAFQADACADAGIADAMQAAAHgCAEIgGAKIgJAIQgGACgIAAgAgQAgIATAAQAHAAAEgEQAEgGAAgEQAAgDgEgGQgEgDgHAAIgTAAg");
	this.shape_30.setTransform(55.5,21.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#383236").s().p("AAXAxIgGgUIghAAIgHAUIgUAAIAihhIATAAIAiBhgAgLANIAXAAIgMgmIAAAAg");
	this.shape_31.setTransform(46.5,21.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#383236").s().p("AgjAxIAAhhIArAAQAGAAAGADQAHAEACADQAEAGABAEQACAFAAAGQAAAGgCAFIgGAIQgDAFgGADQgEACgIAAIgXAAIAAAlgAgQgEIAUAAQAGAAAEgEQADgEAAgFQAAgFgDgFQgFgDgFAAIgUAAg");
	this.shape_32.setTransform(38.9,21.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#383236").s().p("AgOAwQgGgCgGgEQgFgFgDgFQgDgGAAgIIAAgjQAAgIAEgGQACgFAGgFQAIgFAEgBIANgCIAOACQAHADAFAEQAGAEACAFQAEAGAAAJIAAAiQAAAIgDAGQgDAGgFAEQgGAEgGACQgGACgJAAQgIAAgGgCgAgGgeQgCAAgDADQgDACgBAEQgCACAAAGIAAAbQAAAGACACQACAFACABQACACADABIAGABIAHgBQADgBACgCQACgBACgFQACgCAAgGIAAgbQAAgGgCgCQgBgEgDgCQgDgDgCAAIgHgBg");
	this.shape_33.setTransform(26.3,21.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#383236").s().p("AgjAxIAAhhIATAAIAAAlIAWAAQAIABAEACQAGACAEAEQAEACADAGIABAMQAAAHgBAFQgDAGgDAEQgEADgFADQgFADgJAAgAgQAgIATAAQAGAAAEgEQAFgDAAgHQAAgGgFgDQgDgDgHAAIgTAAg");
	this.shape_34.setTransform(85.9,4.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#383236").s().p("Ag4AxIAAhhIATAAIAABQIAcAAIAAhQIATAAIAABQIAbAAIAAhQIAUAAIAABhg");
	this.shape_35.setTransform(74.9,4.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#383236").s().p("AggAxIAAhhIBBAAIAAASIguAAIAAAWIAoAAIAAARIgoAAIAAAXIAuAAIAAARg");
	this.shape_36.setTransform(64.4,4.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#383236").s().p("AAXAxIgGgUIghAAIgGAUIgVAAIAihhIATAAIAiBhgAgLANIAXAAIgMgmIAAAAg");
	this.shape_37.setTransform(55.6,4.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#383236").s().p("AgJAxIAAhPIgaAAIAAgSIBHAAIAAASIgaAAIAABPg");
	this.shape_38.setTransform(47.9,4.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#383236").s().p("AASAxIAAgoIgKAEIgLABIgOgBIgKgHQgFgEgCgEQgDgFAAgKIAAgfIATAAIAAAdQAAAIAFAGQAFAEAIgBIAKgBQAFgBADgDIAAgpIAUAAIAABhg");
	this.shape_39.setTransform(39.6,4.9);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#383236").s().p("AghAxIAAhhIBDAAIAAASIgvAAIAAAWIAnAAIAAARIgnAAIAAAXIAvAAIAAARg");
	this.shape_40.setTransform(31.5,4.9);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#383236").s().p("AAcAxIAAgzIgBAAIgTAmIgOAAIgUgmIgBAAIAAAzIgTAAIAAhhIASAAIAcA6IABAAIAdg6IARAAIAABhg");
	this.shape_41.setTransform(21.7,4.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol15, new cjs.Rectangle(0,0,106,75.5), null);


(lib.Symbol14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFEFE").s().p("AgQBJQgIgCgGgFQgHgEgEgIQgDgGAAgKIAAhKQAAgKADgGQAEgHAHgFQAFgFAJgDQAKgDAGAAQAHAAAJADQAJADAFAFQAIAFADAHQAEAGAAAKIAABKIABAAQgBAJgDAHQgFAIgGAEQgHAFgIACQgGADgKAAQgJAAgHgDgAgIg4QgFABgEADQgEADgCAFQgCAFgBAHIAABBQABAHACAFQADAFADADQAEADAFABIAIABIAJgBQAFgBAEgDQADgEADgEQACgGABgGIAAhBQgBgHgCgFQgDgFgDgDQgEgDgFgBIgJgBIgIABg");
	this.shape.setTransform(102.2,580.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEFEFE").s().p("AgYBIQgHgDgKgIIALgPQAHAGAHADQAIADAIAAIAHgBQAGgCADgCQAFgEACgFQADgEAAgHIAAgZQgLAFgJAEQgHACgHAAQgRABgJgLQgKgJAAgSIAAgRQAAgIAEgJQAFgIAFgEQAIgGAGgCQAJgDAHAAQAIAAAJADQAJADAFAFQAHAFADAGQAEAIAAAJIAABIQAAAKgEAHQgEAIgGAFQgFAEgJADQgHADgKAAQgOAAgKgEgAgIg4IgIAEQgEAFgCADQgDAFAAAHIAAAMQAAAMAGAFQAGAEAIAAQAHAAAHgCQAIgDAJgGIAAgWQAAgHgDgFQgCgFgEgDIgIgEIgJgBg");
	this.shape_1.setTransform(91.1,580.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FEFEFE").s().p("AgsBMIAAgSQAAgJADgIQADgIAFgHQAEgFAIgHIAOgLQAHgDAEgEIALgJQAEgFAEgGQADgGAAgEQAAgGgDgFQgCgEgEgCIgJgFIgKgBQgKAAgHADQgJAEgFAEIgKgNQAGgGAMgFQAKgEANgBQAHABAKACQAHACAIAEQAHAFAEAIQAEAHAAALQAAAHgEAIQgDAHgHAIQgHAGgFAFIggAZIgIAKQgDAGgBAGIAAAGIBGAAIAAARg");
	this.shape_2.setTransform(80.5,580.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEFEFE").s().p("AgeAIIAAgPIA9AAIAAAPg");
	this.shape_3.setTransform(70.8,582.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEFEFE").s().p("AgPBJQgJgCgGgFQgGgEgFgIQgDgHAAgJIAAhKQAAgJADgHQAEgHAHgFQAGgGAJgCQAJgDAGAAQAHAAAJADQAJACAGAGQAGAFAEAHQAFAHAAAJIAABKQAAAJgFAHQgEAIgGAEQgHAFgIACQgGADgKAAQgIAAgHgDgAgIg4QgFABgDADQgFAFgCADQgDAHABAFIAABBQgBAGADAGQADAEAEAEQADADAFABIAIABIAJgBQAFgBAEgDQAEgEACgEQACgFABgHIAAhBQgBgHgCgFQgCgDgEgFQgEgDgFgBIgJgBIgIABg");
	this.shape_4.setTransform(61.2,580.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FEFEFE").s().p("AgYBIQgIgDgJgIIALgPQAHAGAHADQAHADAIAAIAIgBQAFgCAEgCQAEgEACgFQADgEAAgHIAAgZQgKAFgJAEQgIACgGAAQgQABgKgLQgKgJAAgSIAAgRQAAgJAEgIQAEgIAGgEQAHgGAHgCQAIgDAIAAQAIAAAJADQAIACAGAGQAGAEAEAHQAEAJAAAIIAABIQAAAJgEAIQgEAIgGAFQgGAEgJADQgHADgJAAQgOAAgKgEgAgIg4QgEABgEADQgFADgCAFQgCAGAAAGIAAAMQAAAMAFAFQAHAEAHAAQAIAAAHgCQAHgDAJgGIAAgWQAAgHgCgFQgCgFgEgDIgIgEIgJgBIgIABg");
	this.shape_5.setTransform(50.1,580.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FEFEFE").s().p("AgsBMIAAgSQAAgJADgIQAEgIAEgHQAFgFAHgHIAOgLQAHgDAEgEIALgJIAIgLQADgGAAgEQAAgGgDgFQgCgEgEgCIgJgFIgKgBQgJAAgIADQgIAEgFAEIgKgNQAFgGAMgFQAKgEANgBQAHABAKACQAHACAIAEQAHAFAEAIQAEAGAAAMQAAAJgEAGQgDAHgHAIQgHAGgFAFIgWAQIgKAJIgIAKQgDAGAAAGIAAAGIBFAAIAAARg");
	this.shape_6.setTransform(39.5,580.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FEFEFE").s().p("AgFAFQgBgCAAgDIABgEQACgCADAAQADAAACACIACAEIgCAFQgCACgDAAQgDAAgCgCg");
	this.shape_7.setTransform(32.7,587.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FEFEFE").s().p("AgbAXIAGgDQADgCABgEIADgIIABglIApAAIAAA9IgLAAIAAgzIgUAAIAAAQQAAAJgBAGIgEALQgDAEgEACIgIAEg");
	this.shape_8.setTransform(27.8,585.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FEFEFE").s().p("AgIAeIgIgFQgFgDgBgDQgCgEAAgGIAAgPQAAgGACgFQACgEAEgDQADgDAEgCIAJgBQAGAAAEABIAIAFQAEADABAEQACAEAAAGIAAALIgmAAIAAAEQAAAEABACQACADACACIAEACIAFABIAIgBQAEgDAEgDIAGAIQgEAEgHADQgEABgHAAgAgEgUQgDABgBACQgCACgCACQgBADAAAEIAAACIAbAAIAAgCIgBgHIgDgEIgFgDIgFgBIgEABg");
	this.shape_9.setTransform(22,585.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FEFEFE").s().p("AgFArIAAhKIgYAAIAAgLIA7AAIAAALIgYAAIAABKg");
	this.shape_10.setTransform(15.7,584.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FEFEFE").s().p("AgPApIgKgGIAFgJIAJAGQAFACAFAAQAHAAAFgFQAEgDAAgIQAAgHgEgEQgEgEgFAAIgJAAIAAgJIAJAAIAEgBIAFgCIADgFIABgGQAAgDgCgDIgDgDIgFgDIgFgBIgJADIgIAEIgGgIIAKgGQAHgDAHAAIAJABIAIAFQAEADABADQADAFAAAGQAAAGgDAFQgDAGgGACIAFACIAEAFIADAFIAAAGQAAAIgCAEQgCAEgEAEIgJAFIgJABQgIAAgHgCg");
	this.shape_11.setTransform(104.3,562.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FEFEFE").s().p("AgZArIAAgKQAAgFACgFIAFgIIAGgHIAIgGIANgJIAEgGIACgHQAAgDgCgCIgEgEIgFgDIgFAAQgFAAgEACIgIAFIgGgIQAFgFAFgCQAHgCAGAAIAJABIAJAEQAEADACAEQADAFAAAFQAAAFgDAEIgFAIIgIAGIgRAOIgFAGQgCADAAAFIAAACIAnAAIAAAKg");
	this.shape_12.setTransform(98.4,562.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FEFEFE").s().p("AgEAFQgCgCAAgDQAAAAAAAAQAAgBAAgBQAAAAABgBQAAAAABgBQABgCADAAQAEAAABACQABABAAAAQAAABABAAQAAABAAABQAAAAAAAAQAAADgCACQgBACgEAAQgDAAgBgCg");
	this.shape_13.setTransform(91,566);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FEFEFE").s().p("AgEA3IAAgYQgIgBgFgCQgGgCgDgEQgDgDgCgFIgBgKIAAgGIABgLQADgGADgDQADgEAFgCQAGgDAHAAIAAgXIAJAAIAAAXQAHAAAGADQAEACAEAEQAEACABAGQACAEAAAGIAAAIQAAAGgCAEIgFAIQgEAEgEACQgGADgHAAIAAAYgAAFAVQAFAAADgBQADgBADgEIADgGIAAgHIAAgLIgDgGIgGgEQgEgCgEAAgAgMgTIgGAEIgDAGIgBAHIAAAEIABAHIADAGIAFAEQAEACAFAAIAAgqQgEAAgEACg");
	this.shape_14.setTransform(85.8,563.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FEFEFE").s().p("AgJAeIgIgEIgFgHIgCgKIAAgRIACgJIAFgHIAIgFIAJgBQAGAAAEABQAEACAEADQAEADACAEQABAEAAAFIAAARQAAAGgBAEIgGAHIgIAEIgKABQgFAAgEgBgAgEgTIgFACIgDAFQgBABAAAFIAAANIABAHIACAEIAGADIAEAAIAFAAIAFgDQACgBACgDQABgDAAgEIAAgNQAAgEgBgCIgEgFIgFgCIgFgBg");
	this.shape_15.setTransform(78.8,563.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FEFEFE").s().p("AgKAqQgEgCgEgDQgEgDgCgEQgCgGAAgFIABgGIADgGIAEgFIAFgCQgGgDgCgEQgDgGAAgGQAAgGACgEQADgFADgCIAIgFIAIgCIAJACIAIAFQAEADACAEQACAFABAGQgBAGgCAEQgDAGgFACIAFACIAFAFIABAGIABAFQAAAHgCAEQgDAFgEADQgDADgGACQgEABgFAAIgKgBgAgFAGIgFACIgDAFQgCACAAAEQABAGAEAEQADAEAHAAQAIAAADgEQAFgDAAgIQAAgDgBgCIgEgFQgBgBgDgBIgHgBgAgEgfIgFADIgDADIgBAGIABAHIADAEIAFACIAEABIAGgBQADAAABgDIAEgDIABgHIgBgGIgEgDIgEgDIgGgBg");
	this.shape_16.setTransform(69.6,562.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FEFEFE").s().p("AgOApQgFgDgEgDIAGgJIAIAFQAEACAFAAIAEgBQAEgBABgBQACgBABgEQACgDAAgDIAAgPIgLAFIgIACQgJAAgFgGQgFgFAAgKIAAgJQAAgGABgEQADgFADgCIAIgFIAJgBQAFAAAFABIAIAFQAEACABAFQADAEAAAFIAAApQAAAFgDAEQgBAFgEACQgEADgFACQgFABgEAAQgJAAgFgCgAgEgfIgFACIgEAFQgBACAAAEIAAAHQAAAHADADQADABAFAAIAIAAIAJgFIAAgNQAAgEgBgCIgDgFIgFgCIgFgBIgEABg");
	this.shape_17.setTransform(63.3,562.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FEFEFE").s().p("AgZArIAAgKQABgFABgFQACgEADgEIAHgHQADgEAEgCIAGgEIAHgFIAEgGQACgDAAgEQAAgDgCgCIgEgEIgFgDIgEAAQgHAAgDACQgFABgDAEIgGgIQAEgEAGgDQAHgCAHAAIAJABIAIAEQAFAEACADQACAEAAAGQAAAGgCADQgDAFgDADIgIAGIgRAOQgDADgBADQgDADAAAFIAAACIAoAAIAAAKg");
	this.shape_18.setTransform(57.2,562.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FEFEFE").s().p("AgTAaQgFgEAAgJQAAgFACgEIAFgEIAIgDIAHgBIARAAIAAgFQAAgHgEgCQgDgDgHAAIgHABQgGACgDADIgFgIQAGgEAGgCIAKgBQALAAAHAFQAFAFAAALIAAAoIgJAAIgBgGIgBAAQgEADgIACIgHABQgJAAgFgFgAgFAEIgEABIgDADIgBAFQAAAEACADQAEACAEAAIAEgBIAOgGIAAgMIgPAAg");
	this.shape_19.setTransform(48,563.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FEFEFE").s().p("AAOAfIAAgbIgcAAIAAAbIgKAAIAAg9IAKAAIAAAaIAcAAIAAgaIALAAIAAA9g");
	this.shape_20.setTransform(41.9,563.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FEFEFE").s().p("AAOAfIAAgrIAAAAIgcArIgKAAIAAg9IALAAIAAArIAcgrIAKAAIAAA9g");
	this.shape_21.setTransform(35.6,563.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FEFEFE").s().p("AAPAfIAAgbIgdAAIAAAbIgKAAIAAg9IAKAAIAAAaIAdAAIAAgaIAKAAIAAA9g");
	this.shape_22.setTransform(29.2,563.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FEFEFE").s().p("AgIAeQgEgBgEgDQgEgDgCgEQgBgEAAgGIAAgPQgBgGACgEQACgFAEgDQADgDAEgBQAGgCADAAQAGAAAEACIAIAEIAFAHQABAFAAAFIAAALIglAAIAAAEQAAAEABACIAEAFQACACACAAIAGABIAHgBQAEgCADgDIAHAHQgEAEgHADQgEABgHAAgAgEgUIgEADIgEAEQgBADAAAEIAAACIAbAAIAAgCIgBgGQgBgDgCgCQgCgCgDgBIgFAAg");
	this.shape_23.setTransform(23.2,563.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FEFEFE").s().p("AgiAiIAHgFQADgDADgFIADgLIABg1IA0AAIAABUIgMAAIAAhKIgdAAIAAAbQAAALgBAIQgBAJgDAGQgEAGgEADQgEAFgGACg");
	this.shape_24.setTransform(15.9,562.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FEFEFE").s().p("AADAMIAAgXIAJAAIAAAXgAgLAMIAAgXIAJAAIAAAXg");
	this.shape_25.setTransform(107.7,532.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FEFEFE").s().p("AgTAaQgFgFgBgIQABgFACgEQACgDAEgBIAHgDIAHgBIARAAIAAgFQAAgGgEgDQgEgDgGAAIgHABQgEABgFAEIgFgIQAHgEAFgCIAKgBQAMAAAGAFQAFAGABAKIAAAoIgJAAIgCgGIAAAAQgHAEgGABIgHABQgJAAgFgFgAgFAEIgDABIgEADIgCAFQAAAFAEABQADADAFAAIADgBIAOgGIAAgMIgPAAg");
	this.shape_26.setTransform(102.7,536.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FEFEFE").s().p("AgYArIAAhUIAJAAIABAGIAMgGIAHgBQAJAAAFAFQAGAGAAALIAAATQAAAJgGAGQgFAFgKAAIgHAAIgLgDIAAAbgAAAgfIgEABIgKAFIAAAfIAKADIAHAAIAEAAQABAAAAAAQABAAAAgBQABAAAAAAQABgBAAAAIADgEIABgFIAAgRQAAgHgDgDQgEgDgEAAg");
	this.shape_27.setTransform(96.6,538.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FEFEFE").s().p("AgIAeQgFgCgDgCIgGgHQgCgEAAgGIAAgPQAAgGACgEIAFgIIAIgEQAEgCAFAAQAGAAAEACQAFACADACQAEAEABADQACAEAAAGIAAALIgmAAIAAAEQAAAEABACIAEAFIAFACIAEABIAHgCQAEAAAEgEIAHAHQgEAEgGADIgMABQgEAAgFgBgAgEgUIgFADIgDAEIgBAHIAAACIAbAAIAAgCIgBgHIgDgEQgCgCgDgBIgFAAg");
	this.shape_28.setTransform(90.5,536.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FEFEFE").s().p("AgXAfIAAg9IALAAIAAAYIAPAAQAFAAAEACQAEABACADIAFAEIABAIQAAAIgGAGQgGAFgJAAgAgMAVIAOAAQAGAAACgCQAEgCAAgFQAAgEgEgDQgCgCgGAAIgOAAg");
	this.shape_29.setTransform(85,536.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FEFEFE").s().p("AgYArIAAhUIAJAAIABAGIAMgGIAHgBQAJAAAFAFQAGAGAAALIAAATQAAAJgGAGQgFAFgKAAIgHAAIgLgDIAAAbgAAAgfIgEABIgKAFIAAAfIAKADIAHAAIAEAAQABAAAAAAQABAAAAgBQABAAAAAAQABgBAAAAIADgEIABgFIAAgRQAAgHgDgDQgEgDgEAAg");
	this.shape_30.setTransform(78.8,538.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FEFEFE").s().p("AgTAaQgGgFABgIQAAgFACgEIAGgEIAHgDIAHgBIARAAIAAgFQAAgGgDgDQgFgDgGAAIgGABQgFABgFAEIgGgIQAHgEAFgCIALgBQAMAAAGAFQAGAGgBAKIAAAoIgJAAIgBgGIgBAAQgFADgGACIgHABQgKAAgFgFgAgJAFIgDADIgBAFQAAAFACABQAEADAEAAIAEgBIAOgGIAAgMIgPAAg");
	this.shape_31.setTransform(72.6,536.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FEFEFE").s().p("AASArIgHgaQgBgEgCgDIgEgEQAAAAgBgBQAAAAgBAAQAAAAgBAAQgBgBAAAAIgEAAIgOAAIAAAnIgLAAIAAhVIALAAIAAAlIANAAIAEgBQABAAAAAAQAAAAABAAQAAAAABAAQAAgBABAAIAEgEQACgCABgEIAIgZIALAAIgIAZQgCAIgDACQgEAGgDAAQAFABADAEIAFALIAIAcg");
	this.shape_32.setTransform(66.2,535.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FEFEFE").s().p("AAOAfIAAgsIAAAAIgcAsIgKAAIAAg8IAKAAIAAArIABAAIAcgrIAKAAIAAA8g");
	this.shape_33.setTransform(56.4,536.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FEFEFE").s().p("AgTAaQgFgFAAgIQgBgFADgEIAGgEIAHgDIAHgBIARAAIAAgFQAAgGgEgDQgDgDgHAAIgHABQgDABgGAEIgGgIQAGgEAHgCIAKgBQAMAAAGAFQAFAGABAKIAAAoIgKAAIgBgGIgBAAQgFADgGACIgIABQgJAAgFgFgAgJAFIgDADIgCAFQAAAFADABQAEADAEAAIAEgBIAOgGIAAgMIgPAAg");
	this.shape_34.setTransform(47.1,536.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FEFEFE").s().p("AgFAfIAAgzIgTAAIAAgKIAxAAIAAAKIgTAAIAAAzg");
	this.shape_35.setTransform(41.9,536.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FEFEFE").s().p("AgJAeIgIgEIgFgHIgCgKIAAgRIACgJIAFgHIAIgFIAJgBQAGAAAFABQAEACADADQAEADABAEIACAJIAAARIgCAKIgFAHIgIAEQgFABgFAAQgFAAgEgBgAgEgTIgFACIgEAEIAAAHIAAANIAAAHIADAEIAFADIAFAAIAFAAIAFgDIADgEIABgHIAAgNIgBgHIgDgEIgFgCIgFgBg");
	this.shape_36.setTransform(36.2,536.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FEFEFE").s().p("AgSAnQgGgFgBgLIABgcIACgKIAFgKQADgEAEgDIAUgIIAHgFIAFAJIgXALIgHAEIgDAFIgCAIIABABIADgDIAFgBIADgBIACAAQANgBAFAGQAHAGAAAKIAAAOQgBADgBAHIgGAGQgEADgFACQgEABgFAAQgLAAgHgGgAgEgCQgCAAgDACIgDAFQgCADAAADIAAAKQAAAEACADIACAFIAFACIAFAAIAGAAIAEgCIAEgFIABgHIAAgLQAAgIgFgCQgDgCgHAAg");
	this.shape_37.setTransform(30,535.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FEFEFE").s().p("AgTAaQgFgFAAgIQgBgFADgEQACgDAEgBQAEgDADAAIAHgBIAQAAIAAgFQABgGgEgDQgEgDgGAAIgHABQgDABgGAEIgGgIQAGgEAHgCIAKgBQALAAAHAFQAFAGABAKIAAAoIgKAAIgCgGIAAAAIAAAAQgFADgHACIgHABQgJAAgFgFgAgFAEIgEABIgEADIgBAFQAAAFADABQAEADAEAAIAEgBIANgGIAAgMIgOAAg");
	this.shape_38.setTransform(23.7,536.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FEFEFE").s().p("AgdArIAAhVIAiAAQAHAAAEACQAFADADADIAEAIQACAFAAAFQAAAFgCAEIgFAHQgDAEgEACQgEACgHAAIgXAAIAAAjgAgSgBIAVAAQAHAAAEgEQAEgEAAgHQAAgHgEgEQgEgFgHAAIgVAAg");
	this.shape_39.setTransform(18,535.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FEFEFE").s().p("AADAMIAAgXIAJAAIAAAXgAgLAMIAAgXIAJAAIAAAXg");
	this.shape_40.setTransform(12.4,532.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FEFEFE").s().p("AgJAeQgFgCgDgDQgDgCgCgFQgCgDAAgGIAAgRQAAgGACgDQACgFADgCIAIgFQAEgBAFAAQAFAAAFABQAFACADADQADABACAGQACAFAAAEIAAARQAAAEgCAFQgBAEgFADQgCADgGACQgEABgFAAQgFAAgEgBgAgEgUIgFADIgDAEQgCADAAAEIAAANQAAAEACACQAAADACACIAFACIAFABIAFgBIAFgCQACgBACgEIAAgGIAAgNIAAgHIgEgEIgFgDIgFAAg");
	this.shape_41.setTransform(109.4,523.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FEFEFE").s().p("AgXAfIAAg8IAcAAQAFgBADACIAGAEIADAFIABAHQABADgCADQgDAEgDABQAFACABAEQACADAAAEIgBAHIgDAGIgHAEQgCABgGABgAgNAWIARAAQAFgBADgCQACgDAAgEQAAgDgDgDQgEgDgDABIgRAAgAgNgFIARAAQAFAAACgCQACgCAAgDQAAgEgDgDQgDgBgDAAIgRAAg");
	this.shape_42.setTransform(103.3,523.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FEFEFE").s().p("AgFAfIAAgzIgSAAIAAgJIAvAAIAAAJIgTAAIAAAzg");
	this.shape_43.setTransform(97.7,523.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FEFEFE").s().p("AgHAdIgHgEQgEgDgCgEIgBgJIAAgRIABgJIAGgHIAIgFQAEgBAEAAIALABQAEABAGAFIgHAIQgDgDgFgCIgFAAIgEAAIgFADIgEAEIgBAHIAAANIABAGQACAEACABQABABAEABIAEABIAGgBQADgBAEgDIAHAHQgFAFgFABQgFACgGAAQgEAAgFgCg");
	this.shape_44.setTransform(92.6,523.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FEFEFE").s().p("AgEAfIAAgzIgTAAIAAgJIAvAAIAAAJIgSAAIAAAzg");
	this.shape_45.setTransform(87.2,523.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FEFEFE").s().p("AAPAfIAAgaIgdAAIAAAaIgKAAIAAg8IAKAAIAAAZIAdAAIAAgZIAKAAIAAA8g");
	this.shape_46.setTransform(81.5,523.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FEFEFE").s().p("AgIAeIgIgFQgEgCgBgFQgCgDgBgGIAAgPQAAgGACgEQACgFADgDIAIgFIAJgBQAFAAAFABIAIAFIAFAHQABAEABAGIAAALIgmAAIAAAEIABAGIADAEIAGADIAEAAIAHgBQAFgCADgDIAHAIQgFAFgFABIgMACgAgEgUIgFADIgDAEIgBAGIAAADIAbAAIAAgCIgBgHIgDgEIgEgDIgGgBg");
	this.shape_47.setTransform(75.4,523.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FEFEFE").s().p("AgVAfIAAg8IArAAIAAAJIggAAIAAAzg");
	this.shape_48.setTransform(70.4,523.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FEFEFE").s().p("AgUAaQgEgEAAgJQgBgGADgCQABgEAFgCIAGgCIAHgBIARAAIAAgFQABgHgEgCQgEgCgGgBIgHABQgEABgFAEIgGgIQAHgEAGgCIAKgBQAMAAAGAFQAFAFAAALIAAAoIgJAAIgCgGIgLAFIgIABQgJAAgGgFgAgJAFQAAAAgBAAQAAABgBAAQAAAAgBABQAAAAgBABIAAAFQgBAEADADQADACAFAAIAEgBIAFgBIAIgFIAAgLIgTAAg");
	this.shape_49.setTransform(64.6,523.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FEFEFE").s().p("AgIAeQgFgCgDgDQgDgCgDgFQgCgFAAgEIAAgPQAAgGACgEIAFgIQAEgDAEgCQAFgBAEAAQAFAAAFABQAFACADADQADACACAFQACAEAAAGIAAALIgmAAIAAAEIABAGIAEAEIAFADIAEAAIAHgBQAFgBADgEIAHAIQgGAFgEABIgMACQgEAAgFgBgAgEgUIgFADQgCABgBADIgBAGIAAADIAbAAIAAgCIgBgHIgDgEIgEgDIgGgBg");
	this.shape_50.setTransform(55.6,523.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FEFEFE").s().p("AgJAeIgIgFIgGgHQgBgDAAgGIAAgRQAAgGACgDQACgGADgBQADgDAFgCQAFgBAEAAQAGAAAEABIAIAFQAEACABAFQACADAAAGIAAARQAAAGgCADQgCAFgDACIgIAFQgFABgFAAQgFAAgEgBgAgEgUIgFADQgDACAAACQgCADAAAEIAAANIABAGIADAFIAFACIAFABIAFgBIAFgCQACgBABgEQACgCAAgEIAAgNQAAgEgCgDQAAgCgDgCIgFgDIgFAAg");
	this.shape_51.setTransform(49.5,523.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FEFEFE").s().p("AgYAfIAAg8IAdAAQAFgBADACIAGAEQACABABAEQACADAAAEIgCAGQgCAEgEABQAEACADAEQACADAAAEIgBAHIgEAGIgGAEQgEABgFABgAgNAWIAQAAQAGgBACgCQADgCAAgFQAAgEgDgCQgDgDgDABIgSAAgAgNgFIARAAQAEAAACgCQADgBAAgEQAAgEgDgDQgDgBgEAAIgQAAg");
	this.shape_52.setTransform(43.4,523.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FEFEFE").s().p("AgJAeIgIgFQgEgEgBgDQgCgDAAgGIAAgRQAAgGACgDQABgFAEgCIAIgFQAFgBAEAAQAGAAAEABIAIAFQAEACABAFQACADAAAGIAAARQAAAGgCADQgBAEgEADIgIAFQgFABgFAAgAgEgUIgFADQgDACAAACQgCADAAAEIAAANIABAGQACAEACABQABABADABIAFABIAFgBIAFgCQACgBABgEQACgCAAgEIAAgNQAAgEgCgDIgDgEIgFgDIgFAAg");
	this.shape_53.setTransform(37.3,523.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FEFEFE").s().p("AgYArIAAhUIAJAAIABAGQAIgFAEgBIAHgBQAJAAAFAFQAGAGAAALIAAASQAAAKgGAGQgGAFgJABIgHgBIgLgEIAAAcgAAAgfIgEABIgFADIgFADIAAAdIAKAEIAHABIAEgBIAEgCIACgEIABgFIAAgSQAAgGgDgDQgDgDgEAAg");
	this.shape_54.setTransform(31.1,524.7);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FEFEFE").s().p("AAWAmIAAgPIgrAAIAAAPIgKAAIAAgYIAEAAIAEgEIACgFIACgHIADgjIArAAIAAAzIAFAAIAAAYgAgJADIgEALIAdAAIAAgqIgXAAg");
	this.shape_55.setTransform(24.3,524.3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FEFEFE").s().p("AgTAaQgGgFABgIQgBgFADgDQACgEAEgCIAHgCIAHgBIARAAIAAgFQAAgHgEgCQgDgCgHgBIgHABQgEACgFADIgGgIQAHgEAGgCIAKgBQAMAAAGAFQAFAFAAALIAAAoIgJAAIgBgGIgBAAIgLAFIgIABQgJAAgFgFgAgJAFIgDADQgBACgBADQAAAEADADQADACAFAAIAEgBIAFgBIAJgFIAAgLIgUAAg");
	this.shape_56.setTransform(17.8,523.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FEFEFE").s().p("AATArIgIgaIgDgHIgEgDIgEgDIgEAAIgOAAIAAAnIgLAAIAAhVIALAAIAAAlIAOAAIAEAAIADgCIAEgDQADgEAAgDIAIgZIALAAIgIAZQgBAFgEAGQgDAEgEACQAGAAADAEIAEAMIAIAbg");
	this.shape_57.setTransform(11.4,522.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FEFEFE").s().p("AAOAeIAAgrIAAAAIgcArIgKAAIAAg7IALAAIAAAqIAAAAIAcgqIAKAAIAAA7g");
	this.shape_58.setTransform(108.6,510.2);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FEFEFE").s().p("AATAqIgIgZIgDgHIgEgEIgEgCIgSAAIAAAmIgMAAIAAhTIAMAAIAAAkIAOAAIADgBQABAAAAAAQAAAAABAAQAAAAABAAQAAgBABAAIAEgEIADgGIAIgYIALAAIgIAYQgCAGgDAFQgDAEgEABQAGABACAEQADAEACAHIAJAbg");
	this.shape_59.setTransform(99.1,509);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FEFEFE").s().p("AAUAqIAAhKIgnAAIAABKIgMAAIAAhTIA+AAIAABTg");
	this.shape_60.setTransform(91.6,509);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FEFEFE").s().p("AAVAqIAAhBIgBAAIgpBBIgLAAIAAhTIAMAAIAAA/IABAAIAog/IAMAAIAABTg");
	this.shape_61.setTransform(83.8,509);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FEFEFE").s().p("AgSAnQgGgFgBgMIABgbIACgKQACgFACgFQADgDAGgEIAQgIIACgBIADgBIAFgCIAEAJIgPAGIgHAEIgHAEIgDAFIgCAIIABABIADgDIAJgDIABAAQANAAAFAGQAHAGAAAKIAAANQAAAFgCAGIgHAGQgCAEgGABQgEABgFAAQgLABgHgHgAgFgCIgEACIgDAEQgCADAAAEIAAAKIABAHIAEAFIAEACIAFABIAGgBIAEgCIAEgFIABgHIAAgLQAAgIgFgCQgEgDgGAAg");
	this.shape_62.setTransform(76.7,508.7);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FEFEFE").s().p("AAPAeIAAgrIgBAAIgdArIgKAAIAAg7IALAAIAAAqIAAAAIAegqIAKAAIAAA7g");
	this.shape_63.setTransform(70.4,510.2);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FEFEFE").s().p("AgHApIgKgFQgEgDgDgGQgCgEAAgIIAAgeQAAgHACgEQACgEAFgFQAFgEAFgCQAEgBAGAAIABAAQAHAAAGABQAGACAEAEIgFAJQgEgDgFgCQgEgBgGAAIgGABIgGAEQgDACgBADQgCAEAAAFIAAAaQAAAFACAEIAEAGQADADADAAIAGACIAKgCIAJgEIAFAJQgDADgHACQgHADgHAAQgDgBgHgCg");
	this.shape_64.setTransform(64.1,509);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FEFEFE").s().p("AgMApQgGgCgEgDQgEgEgCgFQgDgHAAgGIAAgcQAAgGADgFQACgGAEgDQAEgEAGgDQAGgBAGAAQAHAAAGABQAGADAEAEQAEAEACAFQADAFAAAGIAAAcQAAAGgDAHQgDAFgEAEQgFADgFACIgMADQgFgBgHgCgAgHgfIgGAEIgEAFQgCAEAAAFIAAAaQAAAFACAEIAEAGQADADADAAIAHACQAEAAAEgCQAEAAACgDQADgCABgEQACgEAAgFIAAgaQAAgFgCgEQgBgDgDgCIgGgEIgIgBg");
	this.shape_65.setTransform(53.9,509);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FEFEFE").s().p("AAUAqIAAhKIgnAAIAABKIgMAAIAAhTIA+AAIAABTg");
	this.shape_66.setTransform(46.3,509);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FEFEFE").s().p("AAdA0IAAgTIg5AAIAAATIgLAAIAAgdIAGAAIAFgGQACgCABgFIADgLIACgyIA1AAIAABKIAHAAIAAAdgAgNAIIgCAJIgEAGIAoAAIAAhAIgeAAg");
	this.shape_67.setTransform(38.1,509.9);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FEFEFE").s().p("AgMApQgGgCgEgDQgDgEgDgFQgCgHgBgGIAAgcQABgHACgEQADgGADgDQAEgEAGgDQAFgBAHAAQAIAAAEABQAHADADAEQAEADADAGQADAEgBAHIAAAcQABAIgDAFQgDAFgEAEQgFADgFACIgMADQgEgBgIgCgAgGgfIgHAEIgEAFQgCAEAAAFIAAAaQAAAFACAEIAEAGQADADAEAAIAGACQAEAAADgCQAEAAADgDQADgCACgEQABgEAAgFIAAgaQAAgFgBgEQgCgDgDgCIgHgEIgHgBg");
	this.shape_68.setTransform(27.2,509);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FEFEFE").s().p("AAUAqIAAgmIgnAAIAAAmIgLAAIAAhTIALAAIAAAkIAnAAIAAgkIAMAAIAABTg");
	this.shape_69.setTransform(19.6,509);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FEFEFE").s().p("AAXAqIgGgTIghAAIgHATIgLAAIAdhTIAKAAIAfBTgAgMANIAZAAIgNgnIAAAAg");
	this.shape_70.setTransform(12.1,509);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#262429").s().p("ApXInIAAxNISvAAIAARNg");
	this.shape_71.setTransform(60,544.9);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.lf(["#C6C6C6","#EFEFEF"],[0,1],0,103,0,-269.4).s().p("EgJXAu4MAAAhdvISvAAMAAABdvg");
	this.shape_72.setTransform(60,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol14, new cjs.Rectangle(0,0,120,599.9), null);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.goszakaz_120x600_8();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(0,0,120,123), null);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.goszakaz_120x600_7pngcopy3();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(0,0,120,115), null);


// stage content:
(lib._120x600 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 10-14.svg
	this.instance = new lib.Symbol20();
	this.instance.parent = this;
	this.instance.setTransform(62.6,180.5,1,1,0,0,0,38.5,15.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(171).to({_off:false},0).wait(103));

	// Prosto
	this.instance_1 = new lib.Symbol19();
	this.instance_1.parent = this;
	this.instance_1.setTransform(60.5,122,1,1,0,0,0,34.5,13);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(165).to({_off:false},0).wait(109));

	// Obuchenie.svg
	this.instance_2 = new lib.Symbol18();
	this.instance_2.parent = this;
	this.instance_2.setTransform(61.1,-41,1,1,0,0,0,48.9,31);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(148).to({_off:false},0).wait(1).to({x:61.3,y:-14.5},0).wait(1).to({x:61.5,y:12},0).wait(1).to({x:61.7,y:38.5},0).wait(1).to({x:61.9,y:65},0).wait(122));

	// Kniga
	this.instance_3 = new lib.Symbol9();
	this.instance_3.parent = this;
	this.instance_3.setTransform(342,366,1,1,0,0,0,60,61.5);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(122).to({_off:false},0).wait(10).to({x:327.9,alpha:0.05},0).wait(1).to({x:313.8,y:366.1,alpha:0.1},0).wait(1).to({x:299.7,alpha:0.15},0).wait(1).to({x:285.6,alpha:0.2},0).wait(1).to({x:271.5,alpha:0.25},0).wait(1).to({x:257.4,y:366.2,alpha:0.3},0).wait(1).to({x:243.3,alpha:0.35},0).wait(1).to({x:229.2,alpha:0.4},0).wait(1).to({x:215.1,alpha:0.45},0).wait(1).to({x:201,y:366.3,alpha:0.5},0).wait(1).to({x:186.9,alpha:0.55},0).wait(1).to({x:172.8,alpha:0.6},0).wait(1).to({x:158.7,alpha:0.65},0).wait(1).to({x:144.6,y:366.4,alpha:0.7},0).wait(1).to({x:130.5,alpha:0.75},0).wait(1).to({x:116.4,alpha:0.8},0).wait(1).to({x:102.3,alpha:0.85},0).wait(1).to({x:88.2,y:366.5,alpha:0.9},0).wait(1).to({x:74.1,alpha:0.95},0).wait(1).to({x:60,alpha:1},0).wait(123));

	// Klava
	this.instance_4 = new lib.Symbol8();
	this.instance_4.parent = this;
	this.instance_4.setTransform(343.1,299.5,1,1,0,0,0,60,57.5);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(116).to({_off:false},0).wait(1).to({x:336.5,alpha:0.023},0).wait(1).to({x:329.9,alpha:0.047},0).wait(1).to({x:323.4,alpha:0.07},0).wait(1).to({x:316.8,alpha:0.093},0).wait(1).to({x:310.3,y:299.6,alpha:0.116},0).wait(1).to({x:303.7,alpha:0.14},0).wait(1).to({x:297.1,alpha:0.163},0).wait(1).to({x:290.6,alpha:0.186},0).wait(1).to({x:284,alpha:0.209},0).wait(1).to({x:277.5,alpha:0.233},0).wait(1).to({x:270.9,alpha:0.256},0).wait(1).to({x:264.4,alpha:0.279},0).wait(1).to({x:257.8,y:299.7,alpha:0.302},0).wait(1).to({x:251.2,alpha:0.326},0).wait(1).to({x:244.7,alpha:0.349},0).wait(1).to({x:238.1,alpha:0.372},0).wait(1).to({x:231.6,alpha:0.395},0).wait(1).to({x:225,alpha:0.419},0).wait(1).to({x:218.4,alpha:0.442},0).wait(1).to({x:211.9,alpha:0.465},0).wait(1).to({x:205.3,alpha:0.488},0).wait(1).to({x:198.8,y:299.8,alpha:0.512},0).wait(1).to({x:192.2,alpha:0.535},0).wait(1).to({x:185.7,alpha:0.558},0).wait(1).to({x:179.1,alpha:0.581},0).wait(1).to({x:172.5,alpha:0.605},0).wait(1).to({x:166,alpha:0.628},0).wait(1).to({x:159.4,alpha:0.651},0).wait(1).to({x:152.9,alpha:0.674},0).wait(1).to({x:146.3,alpha:0.698},0).wait(1).to({x:139.8,y:299.9,alpha:0.721},0).wait(1).to({x:133.2,alpha:0.744},0).wait(1).to({x:126.6,alpha:0.767},0).wait(1).to({x:120.1,alpha:0.791},0).wait(1).to({x:113.5,alpha:0.814},0).wait(1).to({x:107,alpha:0.837},0).wait(1).to({x:100.4,alpha:0.86},0).wait(1).to({x:93.8,alpha:0.884},0).wait(1).to({x:87.3,y:300,alpha:0.907},0).wait(1).to({x:80.7,alpha:0.93},0).wait(1).to({x:74.2,alpha:0.953},0).wait(1).to({x:67.6,alpha:0.977},0).wait(1).to({x:61.1,alpha:1},0).wait(115));

	// Vozmozhnost.svg
	this.instance_5 = new lib.Symbol16();
	this.instance_5.parent = this;
	this.instance_5.setTransform(61.1,-37.8,1,1,0,0,0,54,30.8);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(73).to({_off:false},0).wait(1).to({x:61.3,y:-2.5},0).wait(1).to({x:61.6,y:32.8},0).wait(1).to({x:61.9,y:68.2},0).wait(70).to({_off:true},1).wait(127));

	// Mechta.svg
	this.instance_6 = new lib.Symbol15();
	this.instance_6.parent = this;
	this.instance_6.setTransform(60,-51.9,1,1,0,0,0,53,37.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(16).to({y:-37.4},0).wait(1).to({y:-22.9},0).wait(1).to({y:-8.3},0).wait(1).to({y:6.2},0).wait(1).to({y:20.7},0).wait(1).to({y:35.2},0).wait(1).to({y:49.7},0).wait(1).to({y:64.2},0).wait(1).to({y:78.7},0).wait(48).to({_off:true},1).wait(201));

	// Man2
	this.instance_7 = new lib.Symbol22();
	this.instance_7.parent = this;
	this.instance_7.setTransform(161,349,1,1,0,0,0,60,145);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(50).to({_off:false},0).wait(1).to({x:159.1,y:354.8,alpha:0.012},0).wait(1).to({x:156.6,y:360.5,alpha:0.023},0).wait(1).to({x:153.5,y:365.7,alpha:0.035},0).wait(1).to({x:149.8,y:370.4,alpha:0.046},0).wait(1).to({x:124.6,y:380.3,alpha:0.058},0).wait(1).to({x:122.6,y:380.2,alpha:0.069},0).wait(1).to({x:121.6,y:380.1,alpha:0.081},0).wait(1).to({x:120.9,y:380,alpha:0.092},0).wait(1).to({x:120.3,y:379.9,alpha:0.104},0).wait(1).to({x:114.8,y:379,alpha:0.116},0).wait(1).to({x:108.9,y:377.5,alpha:0.127},0).wait(1).to({x:103,y:375.5,alpha:0.139},0).wait(1).to({x:97.4,y:373.2,alpha:0.15},0).wait(1).to({x:91.8,y:370.6,alpha:0.162},0).wait(1).to({x:86.3,y:367.8,alpha:0.173},0).wait(1).to({x:81,y:364.8,alpha:0.185},0).wait(1).to({x:75.7,y:361.6,alpha:0.196},0).wait(1).to({x:70.5,y:358.3,alpha:0.208},0).wait(1).to({x:65.4,y:354.9,alpha:0.22},0).wait(1).to({x:60.4,y:351.5,alpha:0.231},0).wait(1).to({alpha:0.243},0).wait(1).to({alpha:0.254},0).wait(1).to({alpha:0.266},0).wait(1).to({alpha:0.277},0).wait(1).to({alpha:0.289},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.312},0).wait(1).to({alpha:0.324},0).wait(1).to({alpha:0.335},0).wait(1).to({alpha:0.347},0).wait(1).to({alpha:0.358},0).wait(1).to({alpha:0.37},0).wait(1).to({alpha:0.381},0).wait(1).to({alpha:0.393},0).wait(1).to({alpha:0.404},0).wait(1).to({alpha:0.416},0).wait(1).to({alpha:0.428},0).wait(1).to({alpha:0.439},0).wait(1).to({alpha:0.451},0).wait(1).to({alpha:0.462},0).wait(1).to({alpha:0.474},0).wait(1).to({alpha:0.485},0).wait(1).to({alpha:0.497},0).wait(1).to({alpha:0.508},0).wait(1).to({alpha:0.52},0).wait(1).to({alpha:0.532},0).wait(1).to({alpha:0.543},0).wait(1).to({alpha:0.555},0).wait(1).to({alpha:0.566},0).wait(1).to({alpha:0.578},0).wait(1).to({alpha:0.589},0).wait(1).to({alpha:0.601},0).wait(1).to({alpha:0.612},0).wait(1).to({alpha:0.624},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.647},0).wait(1).to({alpha:0.659},0).wait(1).to({alpha:0.67},0).wait(1).to({alpha:0.682},0).wait(1).to({alpha:0.693},0).wait(1).to({alpha:0.705},0).wait(1).to({alpha:0.716},0).wait(1).to({alpha:0.728},0).wait(1).to({alpha:0.739},0).wait(1).to({alpha:0.751},0).wait(1).to({alpha:0.763},0).wait(1).to({alpha:0.774},0).wait(1).to({alpha:0.786},0).wait(1).to({alpha:0.797},0).wait(1).to({alpha:0.809},0).wait(1).to({alpha:0.82},0).wait(1).to({alpha:0.832},0).wait(1).to({alpha:0.843},0).wait(1).to({alpha:0.855},0).wait(1).to({alpha:0.867},0).wait(1).to({alpha:0.878},0).wait(1).to({alpha:0.89},0).wait(1).to({alpha:0.901},0).wait(1).to({alpha:0.913},0).wait(1).to({alpha:0.924},0).wait(1).to({alpha:0.936},0).wait(1).to({alpha:0.947},0).wait(1).to({alpha:0.959},0).wait(1).to({alpha:0.971},0).wait(12).to({_off:true},1).wait(127));

	// Luch.svg
	this.instance_8 = new lib.Symbol17();
	this.instance_8.parent = this;
	this.instance_8.setTransform(171.6,213.4,1,1,0,0,0,56.6,77.5);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(53).to({_off:false},0).wait(1).to({regX:56.9,x:169.5,alpha:0.024},0).wait(1).to({x:167.1,alpha:0.048},0).wait(1).to({x:164.7,alpha:0.071},0).wait(1).to({x:162.2,alpha:0.095},0).wait(1).to({x:159.8,alpha:0.119},0).wait(1).to({x:157.4,alpha:0.143},0).wait(1).to({x:155,alpha:0.167},0).wait(1).to({x:152.6,alpha:0.19},0).wait(1).to({x:150.2,alpha:0.214},0).wait(1).to({x:147.8,alpha:0.238},0).wait(1).to({x:145.3,alpha:0.262},0).wait(1).to({x:142.9,alpha:0.286},0).wait(1).to({x:140.5,alpha:0.31},0).wait(1).to({x:138.1,alpha:0.333},0).wait(1).to({x:135.7,alpha:0.357},0).wait(1).to({x:133.3,alpha:0.381},0).wait(1).to({x:130.9,alpha:0.405},0).wait(1).to({x:128.4,alpha:0.429},0).wait(1).to({x:126,alpha:0.452},0).wait(1).to({x:123.6,alpha:0.476},0).wait(1).to({x:121.2,alpha:0.5},0).wait(1).to({x:118.8,alpha:0.524},0).wait(1).to({x:116.4,alpha:0.548},0).wait(1).to({x:114,alpha:0.571},0).wait(1).to({x:111.5,alpha:0.595},0).wait(1).to({x:109.1,alpha:0.619},0).wait(1).to({x:106.7,alpha:0.643},0).wait(1).to({x:104.3,alpha:0.667},0).wait(1).to({x:101.9,alpha:0.69},0).wait(1).to({x:99.5,alpha:0.714},0).wait(1).to({x:97.1,alpha:0.738},0).wait(1).to({x:94.6,alpha:0.762},0).wait(1).to({x:92.2,alpha:0.786},0).wait(1).to({x:89.8,alpha:0.81},0).wait(1).to({x:87.4,alpha:0.833},0).wait(1).to({x:85,alpha:0.857},0).wait(1).to({x:82.6,alpha:0.881},0).wait(1).to({x:80.2,alpha:0.905},0).wait(1).to({x:77.7,alpha:0.929},0).wait(1).to({x:75.3,alpha:0.952},0).wait(1).to({x:72.9,alpha:0.976},0).wait(1).to({x:70.5,alpha:1},0).wait(1).to({alpha:0.96},0).wait(1).to({alpha:0.92},0).wait(1).to({alpha:0.88},0).wait(1).to({alpha:0.84},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.76},0).wait(1).to({alpha:0.72},0).wait(1).to({alpha:0.68},0).wait(1).to({alpha:0.64},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.56},0).wait(1).to({alpha:0.52},0).wait(1).to({alpha:0.48},0).wait(1).to({alpha:0.44},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.36},0).wait(1).to({alpha:0.32},0).wait(1).to({alpha:0.28},0).wait(1).to({alpha:0.24},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.16},0).wait(1).to({alpha:0.12},0).wait(1).to({alpha:0.08},0).wait(1).to({alpha:0.04},0).wait(1).to({alpha:0},0).wait(26).to({_off:true},1).wait(127));

	// Man1
	this.instance_9 = new lib.Symbol21();
	this.instance_9.parent = this;
	this.instance_9.setTransform(342,359.5,1,1,0,0,0,60,129.5);
	this.instance_9.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1).to({x:329.7,alpha:0.043},0).wait(1).to({x:317.5,alpha:0.087},0).wait(1).to({x:305.2,y:359.6,alpha:0.13},0).wait(1).to({x:293,alpha:0.174},0).wait(1).to({x:280.7,alpha:0.217},0).wait(1).to({x:268.4,alpha:0.261},0).wait(1).to({x:256.2,y:359.7,alpha:0.304},0).wait(1).to({x:243.9,alpha:0.348},0).wait(1).to({x:231.7,alpha:0.391},0).wait(1).to({x:219.4,alpha:0.435},0).wait(1).to({x:207.1,alpha:0.478},0).wait(1).to({x:194.9,y:359.8,alpha:0.522},0).wait(1).to({x:182.6,alpha:0.565},0).wait(1).to({x:170.3,alpha:0.609},0).wait(1).to({x:158.1,alpha:0.652},0).wait(1).to({x:145.8,alpha:0.696},0).wait(1).to({x:133.6,y:359.9,alpha:0.739},0).wait(1).to({x:121.3,alpha:0.783},0).wait(1).to({x:109,alpha:0.826},0).wait(1).to({x:96.8,alpha:0.87},0).wait(1).to({x:84.5,y:360,alpha:0.913},0).wait(1).to({x:72.3,alpha:0.957},0).wait(1).to({x:60,alpha:1},0).wait(39).to({_off:true},1).wait(211));

	// goszakaz_120x600.svg
	this.instance_10 = new lib.Symbol14();
	this.instance_10.parent = this;
	this.instance_10.setTransform(60.4,300,1,1,0,0,0,60,299.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(274));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(60.4,210.4,401.7,689.7);
// library properties:
lib.properties = {
	id: '5CB9BFCFFF109C438B5C314C6DB14E90',
	width: 120,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/120x600_atlas_.png", id:"120x600_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['5CB9BFCFFF109C438B5C314C6DB14E90'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;